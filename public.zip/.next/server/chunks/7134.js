"use strict";
exports.id = 7134;
exports.ids = [7134];
exports.modules = {

/***/ 7134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4574);
/* harmony import */ var _components_product_layout_01__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1510);
/* harmony import */ var _components_product_filter_layout_01__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1967);
/* harmony import */ var _ui_filter_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(637);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8115);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8663);
/* harmony import */ var _components_pagination_02__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5116);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2037);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_range__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3715);
/* harmony import */ var _ui_nice_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(388);
/* harmony import */ var _ui_input_range__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3453);















function reducer(state, action) {
    switch(action.type){
        case "SET_PRODUCTS":
            return {
                ...state,
                products: action.payload
            };
        default:
            return state;
    }
}
const STEP = 1;
const MIN = 18;
const MAX = 100;
const POSTS_PER_PAGE = 2;
const ExploreProductAreaPaquete = ({ className , space , data  })=>{
    console.log(data);
    const [anuncios, setAnuncios] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data);
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [anunciosList, setAnunciosList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ciudadList, setCiudadList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [etniaList, setEtniaList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [colorCabelloList, setColorCabelloList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [colorOjosList, setColorOjosList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [values, setValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        18,
        100
    ]);
    const [ciudadBuscar, setCiudadBuscar] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [etniaBuscar, setEtniaBuscar] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [colorCabello, setColorCabello] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [colorOjos, setColorOjos] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [edadRango, setEdadRango] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const numberOfPages = Math.ceil(data.products.length / POSTS_PER_PAGE);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setAnunciosList(data.products);
    }, []);
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, {
        filterToggle: false,
        products: data.products || [],
        allProducts: data.products || []
    });
    const paginationHandler = (page)=>{
        dispatch({
            type: "SET_PAGE",
            payload: page
        });
        const start = (page - 1) * POSTS_PER_PAGE;
        dispatch({
            type: "SET_PRODUCTS",
            payload: data.products.slice(start, start + POSTS_PER_PAGE)
        });
        document.getElementById("explore-id");
    };
    const obtenerDatos = async ()=>{
        const data2 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getCiudadFiltro");
        const result2 = await data2.json();
        console.log(result2.ciudades);
        setCiudadList(result2.ciudades);
    };
    //obtenerDatos();
    const searcher = (e)=>{
        setSearch(e.target.value);
    };
    ciudadBuscar;
    const selectCiudad = (e)=>{
        console.log(e);
        setCiudadBuscar(e.value);
    };
    const selectEtnia = (e)=>{
        console.log(e);
        setEtniaBuscar(e.value);
    };
    const selectColorCabello = (e)=>{
        console.log(e);
        setColorCabello(e.value);
    };
    const selectColorOjos = (e)=>{
        console.log(e);
        setColorOjos(e.value);
    };
    const buscarEvento = ()=>{
        console.log(ciudadBuscar);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                ciudad: ciudadBuscar
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getAnunciosHombresAllByCiudad", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            setAnunciosList(json.anuncios);
        }).catch((error)=>toast("Ocurrio un error"));
    };
    //metodo de filtrado 2  
    const dataOrigin = data.products;
    const results = !search ? dataOrigin : dataOrigin.filter((dato)=>dato.nombre.toLowerCase().includes(search.toLocaleLowerCase()));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("rn-product-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row g-5",
                children: anunciosList.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: anunciosList.slice(0, 1000).map((prod)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-5 col-lg-4 col-md-6 col-sm-6 col-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_layout_01__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                overlay: true,
                                placeBid: !!data.placeBid,
                                title: prod.nombre,
                                paquete_activo: prod.paquete_activo,
                                slug: prod.slug,
                                latestBid: prod.latestBid,
                                price: prod.price,
                                likeCount: prod.likeCount,
                                auction_date: prod.auction_date,
                                image: "https://bo.ubunnies.com/backendUbunnie/" + prod.fotografia_portada,
                                authors: prod.authors,
                                bitCount: prod.bitCount,
                                usuario: prod.usuario
                            })
                        }, prod.cod))
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: "No hay anuncios para mostrar"
                })
            })
        })
    });
};
ExploreProductAreaPaquete.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExploreProductAreaPaquete);


/***/ })

};
;