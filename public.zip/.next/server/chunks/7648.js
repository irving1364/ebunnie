"use strict";
exports.id = 7648;
exports.ids = [7648];
exports.modules = {

/***/ 1967:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_nice_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(388);
/* harmony import */ var _ui_input_range__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3453);





const ProductFilter = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(({ slectHandler , sortHandler , priceHandler , inputs  }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "default-exp-wrapper default-exp-expand",
        ref: ref,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "inner",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "filter-select-option",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "filter-leble",
                            children: "Con Experiencia"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            options: [
                                {
                                    value: "Poca",
                                    text: "Poca"
                                },
                                {
                                    value: "Media",
                                    text: "Media"
                                }
                            ],
                            placeholder: "Selecciona",
                            onChange: sortHandler,
                            name: "like"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "filter-select-option",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "filter-leble",
                            children: "Etnia"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            options: [
                                {
                                    value: "all",
                                    text: "Catira"
                                },
                                {
                                    value: "art",
                                    text: "Morena"
                                },
                                {
                                    value: "music",
                                    text: "Trige\xf1a"
                                }
                            ],
                            placeholder: "Category",
                            onChange: slectHandler,
                            name: "category"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "filter-select-option",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "filter-leble",
                            children: "Edad"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            options: [
                                {
                                    value: "all",
                                    text: "18-25"
                                },
                                {
                                    value: "Art Decco",
                                    text: "25-30"
                                },
                                {
                                    value: "BoredApeYachtClub",
                                    text: "30-40"
                                },
                                {
                                    value: "MutantApeYachtClub",
                                    text: "40+"
                                }
                            ],
                            placeholder: "Collections",
                            onChange: slectHandler,
                            name: "collection"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "filter-select-option",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "filter-leble",
                            children: "Nacionalidad"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            options: [
                                {
                                    value: "all",
                                    text: "Venezolana"
                                },
                                {
                                    value: "fixed-price",
                                    text: "Colombiana"
                                },
                                {
                                    value: "timed-auction",
                                    text: "Argentina"
                                }
                            ],
                            placeholder: "Sale type",
                            onChange: slectHandler,
                            name: "sale_type"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "filter-select-option",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "filter-leble",
                            children: "Precio Rango"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "price_filter s-filter clear",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                action: "#",
                                method: "GET",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input_range__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    values: inputs.price,
                                    onChange: priceHandler
                                })
                            })
                        })
                    ]
                })
            ]
        })
    }));
ProductFilter.displayName = "ProductFilter";
ProductFilter.propTypes = {
    slectHandler: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func),
    sortHandler: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func),
    priceHandler: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func),
    inputs: prop_types__WEBPACK_IMPORTED_MODULE_2___default().shape({
        price: prop_types__WEBPACK_IMPORTED_MODULE_2___default().arrayOf((prop_types__WEBPACK_IMPORTED_MODULE_2___default().number))
    })
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ProductFilter)));


/***/ }),

/***/ 637:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);



const FilterButton = ({ onClick , open  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "view-more-btn text-start text-sm-end",
        "data-sal-delay": "150",
        "data-sal": "slide-up",
        "data-sal-duration": "800",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
            type: "button",
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("discover-filter-button discover-filter-activation btn btn-primary", open && "open"),
            onClick: onClick,
            children: [
                "Filter",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "feather-filter"
                })
            ]
        })
    });
FilterButton.propTypes = {
    onClick: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().func.isRequired),
    open: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool)
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (FilterButton)));


/***/ }),

/***/ 4475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4574);
/* harmony import */ var _components_product_layout_01__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1510);
/* harmony import */ var _components_product_filter_layout_01__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1967);
/* harmony import */ var _ui_filter_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(637);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8115);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8663);
/* harmony import */ var _components_pagination_02__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5116);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2037);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_range__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3715);
/* harmony import */ var _ui_nice_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(388);
/* harmony import */ var _ui_input_range__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3453);















function reducer(state, action) {
    switch(action.type){
        case "SET_PRODUCTS":
            return {
                ...state,
                products: action.payload
            };
        default:
            return state;
    }
}
const STEP = 1;
const MIN = 18;
const MAX = 100;
const POSTS_PER_PAGE = 2;
const ExploreProductArea = ({ className , space , data  })=>{
    console.log(data);
    const [anuncios, setAnuncios] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data);
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [anunciosList, setAnunciosList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ciudadList, setCiudadList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [etniaList, setEtniaList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [colorCabelloList, setColorCabelloList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [colorOjosList, setColorOjosList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [values, setValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        18,
        100
    ]);
    const [ciudadBuscar, setCiudadBuscar] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [etniaBuscar, setEtniaBuscar] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [colorCabello, setColorCabello] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [colorOjos, setColorOjos] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [edadRango, setEdadRango] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const numberOfPages = Math.ceil(data.products.length / POSTS_PER_PAGE);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
        setAnunciosList(data.products);
    }, []);
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, {
        filterToggle: false,
        products: data.products || [],
        allProducts: data.products || []
    });
    const paginationHandler = (page)=>{
        dispatch({
            type: "SET_PAGE",
            payload: page
        });
        const start = (page - 1) * POSTS_PER_PAGE;
        dispatch({
            type: "SET_PRODUCTS",
            payload: data.products.slice(start, start + POSTS_PER_PAGE)
        });
        document.getElementById("explore-id");
    };
    /*  const itemsToFilter = [...data.products];
  
    const [state, dispatch] = useReducer(reducer, {
        filterToggle: true,
        products: data.products || [],
        allProducts: data.products || [],
        inputs: { price: [0, 100] },
    });
  
    const filterRef = useRef(null);
    const filterHandler = () => {
        dispatch({ type: "FILTER_TOGGLE" });
        if (!filterRef.current) return;
        slideToggle(filterRef.current);
    };

    const numberOfPages = Math.ceil(data.products.length / POSTS_PER_PAGE);
    console.log(state.allProducts);
    console.log(numberOfPages);

    const paginationHandler = (page) => {
        dispatch({ type: "SET_PAGE", payload: page });
        const start = (page - 1) * POSTS_PER_PAGE;
        dispatch({
            type: "SET_PRODUCTS",
            payload: data.products.slice(start, start + POSTS_PER_PAGE),
        });
        document
            .getElementById("explore-id");
    };

    const slectHandler = ({ value }, name) => {
        dispatch({ type: "SET_INPUTS", payload: { [name]: value } });
    };

    const priceHandler = (value) => {
        dispatch({ type: "SET_INPUTS", payload: { price: value } });
    };

    const sortHandler = ({ value }) => {
        const sortedProducts = state.products.sort((a, b) => {
            if (value === "most-liked") {
                return a.likeCount < b.likeCount ? 1 : -1;
            }
            return a.likeCount > b.likeCount ? 1 : -1;
        });
        dispatch({ type: "SET_PRODUCTS", payload: sortedProducts });
    };

    const filterMethods = (item, filterKey, value) => {
        if (value === "all") return false;
        let itemKey = filterKey;
        if (filterKey === "category") {
            itemKey = "categories";
        }
        
        
        if (Array.isArray(item[itemKey])) {
            return !item[itemKey].includes(value);
        }
        if (filterKey === "collection") {
            return item[itemKey].name !== value;
        }
        return item[itemKey] !== value;
    };

    const itemFilterHandler = useCallback(() => {
        let filteredItems = [];

        filteredItems = itemsToFilter.filter((item) => {
            // eslint-disable-next-line no-restricted-syntax
            for (const key in state.inputs) {
                if (filterMethods(item, key, state.inputs[key])) return false;
            }
            return true;
        });
        dispatch({ type: "SET_PRODUCTS", payload: filteredItems });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [state.inputs]);

    useEffect(() => {
        itemFilterHandler();
    }, [itemFilterHandler]);
*/ const obtenerDatos = async ()=>{
        const data2 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getCiudadFiltro");
        const result2 = await data2.json();
        console.log(result2.ciudades);
        setCiudadList(result2.ciudades);
    /*
    const data3 = await fetch(process.env.url + "perfil/getEtniaFiltro")
    const result3 = await data3.json();set
    console.log(result3.etnia);
    setEtniaList(result3.etnia)
    console.log(etniaList);

    const data4 = await fetch(process.env.url + "perfil/getColorCabelloFiltro")
    const result4 = await data4.json();
    console.log(result4.cabello);
    setColorCabelloList(result4.cabello)

    const data5 = await fetch(process.env.url + "perfil/getColorOjosFiltro")
    const result5 = await data5.json();
    console.log(result5.ojos);
    setColorOjosList(result5.ojos)
    */ };
    //obtenerDatos();
    const searcher = (e)=>{
        setSearch(e.target.value);
    };
    ciudadBuscar;
    const selectCiudad = (e)=>{
        console.log(e);
        setCiudadBuscar(e.value);
    };
    const selectEtnia = (e)=>{
        console.log(e);
        setEtniaBuscar(e.value);
    };
    const selectColorCabello = (e)=>{
        console.log(e);
        setColorCabello(e.value);
    };
    const selectColorOjos = (e)=>{
        console.log(e);
        setColorOjos(e.value);
    };
    const buscarEvento = ()=>{
        console.log(ciudadBuscar);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                ciudad: ciudadBuscar
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getAnunciosMujeresAllByCiudad", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            //data.products = json.anuncios;
            //            const results = json.anuncios;
            setAnunciosList(json.anuncios);
        }).catch((error)=>toast("Ocurrio un error"));
    };
    //metodo de filtrado 1 
    /*  let results = []
 if(!search)
 {
     results = users
 }else{
      results = users.filter( (dato) =>
      dato.name.toLowerCase().includes(search.toLocaleLowerCase())
  )
 } */ //metodo de filtrado 2   
    //console.log(anuncios);
    const dataOrigin = data.products;
    //console.log(dataOrigin);
    const results = !search ? dataOrigin : dataOrigin.filter((dato)=>dato.nombre.toLowerCase().includes(search.toLocaleLowerCase()));
    //console.log(results);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("rn-product-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row mb--10 align-items-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-lg-2 col-md-6 col-sm-12 filter-select-option mt--0",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "filter-leble",
                                    children: "Ciudad"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    onChange: selectCiudad,
                                    options: ciudadList,
                                    placeholder: "Selecciona",
                                    name: "etnia"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-1"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-lg-1 col-md-6 col-sm-12 filter-select-option mt-10",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "input-box",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                        color: "primary-alta",
                                        fullwidth: true,
                                        type: "button",
                                        "data-btn": "preview",
                                        onClick: buscarEvento,
                                        children: "Buscar"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row g-5",
                    children: anunciosList.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: anunciosList.slice(0, 1000).map((prod)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-5 col-lg-4 col-md-6 col-sm-6 col-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_layout_01__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    overlay: true,
                                    placeBid: !!data.placeBid,
                                    title: prod.nombre,
                                    paquete_activo: prod.paquete_activo,
                                    slug: prod.slug,
                                    latestBid: prod.latestBid,
                                    price: prod.price,
                                    likeCount: prod.likeCount,
                                    auction_date: prod.auction_date,
                                    image: "https://bo.ubunnies.com/backendUbunnie/" + prod.fotografia_portada,
                                    authors: prod.authors,
                                    bitCount: prod.bitCount,
                                    usuario: prod.usuario
                                })
                            }, prod.cod))
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "No hay anuncios para mostrar"
                    })
                })
            ]
        })
    });
};
ExploreProductArea.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExploreProductArea);


/***/ }),

/***/ 1498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_09)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: ./src/components/ui/slider/index.jsx
var slider = __webpack_require__(8179);
// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(8663);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(4643);
// EXTERNAL MODULE: ./src/components/ui/client-avatar/index.jsx
var client_avatar = __webpack_require__(2542);
// EXTERNAL MODULE: ./src/components/ui/button/index.jsx
var ui_button = __webpack_require__(3715);
// EXTERNAL MODULE: ./src/components/modals/placebid-modal/index.jsx
var placebid_modal = __webpack_require__(3709);
;// CONCATENATED MODULE: ./src/containers/hero/layout-09/slide.jsx










const CountdownTimer = dynamic_default()(()=>__webpack_require__.e(/* import() */ 908).then(__webpack_require__.bind(__webpack_require__, 908)), {
    loadableGenerated: {
        modules: [
            "..\\containers\\hero\\layout-09\\slide.jsx -> " + "@ui/countdown/layout-02"
        ]
    },
    ssr: false
});
const ShareDropdown = dynamic_default()(()=>__webpack_require__.e(/* import() */ 3823).then(__webpack_require__.bind(__webpack_require__, 3823)), {
    loadableGenerated: {
        modules: [
            "..\\containers\\hero\\layout-09\\slide.jsx -> " + "@components/share-dropdown"
        ]
    },
    ssr: false
});
const SingleSlide = ({ title , path , latestBid , price , likeCount , image , auction_date , authors , bitCount , highest_bid , categories , properties  })=>{
    const [showBidModal, setShowBidModal] = (0,external_react_.useState)(false);
    const handleBidModal = ()=>{
        setShowBidModal((prev)=>!prev);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            image?.src && /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "slider-bg",
                src: "/model.png",
                alt: "Slider BG",
                quality: 100,
                priority: true,
                fill: true,
                sizes: "100vw",
                style: {
                    objectFit: "cover"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row d-flex align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-7",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "inner text-left",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                        path: path,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "title theme-gradient",
                                            children: title
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-5"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(placebid_modal/* default */.Z, {
                show: showBidModal,
                handleModal: handleBidModal
            })
        ]
    });
};
SingleSlide.propTypes = {
    title: (external_prop_types_default()).string.isRequired,
    path: (external_prop_types_default()).string.isRequired,
    latestBid: (external_prop_types_default()).string.isRequired,
    price: (external_prop_types_default()).string,
    likeCount: (external_prop_types_default()).number,
    image: types/* ImageType */.__,
    auction_date: (external_prop_types_default()).string,
    authors: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        name: (external_prop_types_default()).string.isRequired,
        slug: (external_prop_types_default()).string.isRequired,
        image: types/* ImageType */.__
    })),
    bitCount: (external_prop_types_default()).number,
    highest_bid: external_prop_types_default().shape({
        user: external_prop_types_default().shape({
            name: (external_prop_types_default()).string.isRequired,
            path: (external_prop_types_default()).string.isRequired,
            image: types/* ImageType */.__
        }),
        amount: (external_prop_types_default()).string.isRequired
    }),
    categories: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        id: types/* IDType */.iJ,
        value: (external_prop_types_default()).string.isRequired,
        type: (external_prop_types_default()).string.isRequired
    })),
    properties: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        id: types/* IDType */.iJ,
        value: (external_prop_types_default()).string.isRequired,
        type: (external_prop_types_default()).string.isRequired
    }))
};
/* harmony default export */ const slide = (SingleSlide);

;// CONCATENATED MODULE: ./src/containers/hero/layout-09/index.jsx





const sliderOptions = {
    dots: false,
    arrows: false,
    adaptiveHeight: true,
    autoplaySpeed: 2000,
    responsive: [
        {
            breakpoint: 1599,
            settings: {
                dots: true,
                arrows: false
            }
        }
    ]
};
const HeroArea = ({ data  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "rn-slider-area fullscreen-slide",
        children: data?.banners && /*#__PURE__*/ jsx_runtime_.jsx(slider/* default */.Z, {
            options: sliderOptions,
            className: "slider-activation-banner-3 game-banner-slick-wrapper slick-arrow-style-one rn-slick-dot-style",
            children: data?.banners.map((banner)=>/*#__PURE__*/ jsx_runtime_.jsx(slider/* SliderItem */.w, {
                    className: "d-flex align-items-center padding-controler-slide-product-2 justify-content-center slide slide-style-2 fullscreen_image-banner position-relative",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(slide, {
                        title: banner.title,
                        path: banner.path,
                        latestBid: banner.latestBid,
                        price: banner.price,
                        likeCount: banner.likeCount,
                        image: banner.image,
                        auction_date: banner.auction_date,
                        authors: banner.authors,
                        bitCount: banner.bitCount,
                        highest_bid: banner.highest_bid,
                        categories: banner.categories,
                        properties: banner.properties
                    })
                }, banner.id))
        })
    });
HeroArea.propTypes = {
    data: external_prop_types_default().shape({
        banners: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            id: types/* IDType */.iJ,
            title: (external_prop_types_default()).string.isRequired,
            path: (external_prop_types_default()).string.isRequired,
            latestBid: (external_prop_types_default()).string.isRequired,
            price: (external_prop_types_default()).string,
            likeCount: (external_prop_types_default()).number,
            image: types/* ImageType */.__,
            auction_date: (external_prop_types_default()).string,
            authors: external_prop_types_default().arrayOf(external_prop_types_default().shape({
                name: (external_prop_types_default()).string.isRequired,
                slug: (external_prop_types_default()).string.isRequired,
                image: types/* ImageType */.__
            })),
            bitCount: (external_prop_types_default()).number,
            highest_bid: external_prop_types_default().shape({
                user: external_prop_types_default().shape({
                    name: (external_prop_types_default()).string.isRequired,
                    path: (external_prop_types_default()).string.isRequired,
                    image: types/* ImageType */.__
                }),
                amount: (external_prop_types_default()).string.isRequired
            }),
            categories: external_prop_types_default().arrayOf(external_prop_types_default().shape({
                id: types/* IDType */.iJ,
                value: (external_prop_types_default()).string.isRequired,
                type: (external_prop_types_default()).string.isRequired
            })),
            properties: external_prop_types_default().arrayOf(external_prop_types_default().shape({
                id: types/* IDType */.iJ,
                value: (external_prop_types_default()).string.isRequired,
                type: (external_prop_types_default()).string.isRequired
            }))
        }))
    })
};
/* harmony default export */ const layout_09 = (HeroArea);


/***/ }),

/***/ 7606:
/***/ ((module) => {

module.exports = JSON.parse('{"title":"home-09","content":[{"section":"hero-section","banners":[{"id":1,"title":"","path":"/collection","published_at":"20-JUN-2021 08:03:00","latestBid":"1/20","price":"0.244wETH","likeCount":322,"image":{"src":"/model.jpg"},"auction_date":"2024-10-08","authors":[{"name":"Mark Jordan","slug":"/author","image":{"src":"/images/client/client-2.png"}},{"name":"Farik Shaikh","slug":"/author","image":{"src":"/images/client/client-3.png"}},{"name":"John Doe","slug":"/author","image":{"src":"/images/client/client-5.png"}}],"bitCount":15,"highest_bid":{"user":{"name":"Atif Aslam","path":"/collection","image":{"src":"/images/client/client-7.png"}},"amount":"0.115wETH"},"categories":[{"id":1,"value":"APP","type":"ZARY"},{"id":2,"value":"TRIBUTE","type":"SOMALIAN"},{"id":3,"value":"PIPE","type":"TUNA"}],"properties":[{"id":1,"type":"HYPE TYPE","value":"CALM AF (STILL)"},{"id":2,"type":"BASTARDNESS","value":"C00LIO BASTARD"}]}]},{"section":"about-section","title":"AN NURON THEME JUST FOR GAMERS","description":"Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio sed non. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit."},{"section":"live-explore-section","section_title":{"title":"Live Bidding"}},{"section":"product-section","section_title":{"title":"OUR All NFT\'S"}},{"section":"product-section-two","section_title":{"title":"OUR All NFT\'S"}},{"section":"collection-section","section_title":{"title":"Top Collection"}},{"section":"service-section","section_title":{"title":"Make Easyer"},"items":[{"id":1,"title":"Set up your wallet","path":"/connect","subtitle":"Step-01","description":"Powerful features and inclusions, which makes Nuron standout, easily customizable and scalable.","images":[{"src":"/images/icons/shape-7.png"}]},{"id":2,"title":"Create your collection","path":"/collection","subtitle":"Step-02","description":"A great collection of beautiful website templates for your need. Choose the best suitable template.","images":[{"src":"/images/icons/shape-1.png"}]},{"id":3,"title":"Add your NFT\'s","path":"/connect","subtitle":"Step-03","description":"We\'ve made the template fully responsive, so it looks great on all devices: desktop, tablets and.","images":[{"src":"/images/icons/shape-5.png"}]},{"id":4,"title":"Sell Your NFT\'s","path":"/creator","subtitle":"Step-04","description":"I throw myself down among the tall grass by the stream as I lie close to the earth NFT\'s.","images":[{"src":"/images/icons/shape-6.png"}]}]}]}');

/***/ })

};
;