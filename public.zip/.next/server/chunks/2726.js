"use strict";
exports.id = 2726;
exports.ids = [2726];
exports.modules = {

/***/ 6678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);
/* harmony import */ var react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2040);
/* harmony import */ var react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _ui_input_range__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3453);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2037);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_range__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 












const STEP = 1;
const MIN = 18;
const MAX = 100;
const CreateNewAreaPerfilMiembro = ({ className , space  })=>{
    const [values, setValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        18,
        100
    ]);
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__/* .useLocalStorage */ ._)("tokens");
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [ciudadesList, setCiudadesList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [tipoScortList, setTipoScortList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [perfilList, setPerfilList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [edad, setEdad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [html, setHtml] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    function onChange(e) {
        setHtml(e.target.value);
    }
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
    }, []);
    const priceHandler = (value)=>{
        setEdad(value);
        //dispatch({ type: "SET_INPUTS", payload: { price: value } });
        console.log(edad);
    };
    const obtenerDatos = async ()=>{
        const data = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getCiudades");
        const result = await data.json();
        setCiudadesList(result.ciudades);
        const data5 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getTipoScort");
        const result5 = await data5.json();
        setTipoScortList(result5.tipo_scort);
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data6 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getPerfilMiembro", requestOptionsPerfil);
        const result6 = await data6.json();
        setPerfilList(result6.perfil);
        console.log(perfilList);
        setHtml(perfilList.sobre_mi);
        //var min = parseInt(perfilList.edad_minima);
        //var max = parseInt(perfilList.edad_maxima);
        //setValues([min, max]);
        console.log(ciudadesList);
        console.log(perfilList);
        setIsLoad(true);
    };
    const notify = ()=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Your product has submitted");
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    const onSubmit = async (e)=>{
        console.log(values);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                token: token,
                cod_ciudad: e.ciudad_base,
                tipo_escort: e.tipo,
                edad_minima: values[0],
                edad_maxima: values[1],
                sobre_mi: html
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addPerfilMiembro", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                console.log(1);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                console.log(json);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    if (isLoad) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "mt-5", className),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        action: "#",
                        onSubmit: handleSubmit(onSubmit),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row g-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-wrapper-one",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "codigo_pais",
                                                                className: "form-label",
                                                                children: "Ciudad de Interes"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "ciudad_base",
                                                                id: "ciudad_base",
                                                                "aria-label": "Default select example",
                                                                ...register("ciudad_base", {
                                                                    required: "Debe seleccionar un Ciudad Base"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    ciudadesList?.map((ciudad)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            selected: perfilList.cod_ciudad == ciudad.cod,
                                                                            value: ciudad.cod,
                                                                            children: ciudad.ciudad
                                                                        }, ciudad.cod)),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.ciudad_base && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.ciudad_base?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "tipo",
                                                                className: "form-label",
                                                                children: "Tipo de Escort de Preferencia"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "tipo",
                                                                id: "tipo",
                                                                "aria-label": "Default select example",
                                                                ...register("tipo", {
                                                                    required: "Debe seleccionar un tipo de Escort"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    tipoScortList?.map((tipo)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                            selected: perfilList.tipo_escort == tipo.cod,
                                                                            value: tipo.cod,
                                                                            children: [
                                                                                tipo.tipo_scort,
                                                                                " "
                                                                            ]
                                                                        }, tipo.cod)),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.tipo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.tipo?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "segunda_ciudad",
                                                                className: "form-label",
                                                                children: "Rango de edad, de su interes."
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "price_filter s-filter clear mt-4",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_range__WEBPACK_IMPORTED_MODULE_12__.Range, {
                                                                    values: values,
                                                                    step: STEP,
                                                                    min: MIN,
                                                                    max: MAX,
                                                                    onChange: (values)=>setValues(values),
                                                                    renderTrack: ({ props , children  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            onMouseDown: props.onMouseDown,
                                                                            onTouchStart: props.onTouchStart,
                                                                            style: {
                                                                                ...props.style,
                                                                                height: "36px",
                                                                                display: "flex",
                                                                                width: "100%"
                                                                            },
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                ref: props.ref,
                                                                                style: {
                                                                                    height: "5px",
                                                                                    width: "100%",
                                                                                    borderRadius: "4px",
                                                                                    background: (0,react_range__WEBPACK_IMPORTED_MODULE_12__.getTrackBackground)({
                                                                                        values,
                                                                                        colors: [
                                                                                            "#ccc",
                                                                                            "#548BF4",
                                                                                            "#ccc"
                                                                                        ],
                                                                                        min: MIN,
                                                                                        max: MAX
                                                                                    }),
                                                                                    alignSelf: "center"
                                                                                },
                                                                                children: children
                                                                            })
                                                                        }),
                                                                    renderThumb: ({ index , props , isDragged  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            ...props,
                                                                            style: {
                                                                                ...props.style,
                                                                                height: "14px",
                                                                                width: "14px",
                                                                                borderRadius: "4px",
                                                                                backgroundColor: "#FFF",
                                                                                display: "flex",
                                                                                justifyContent: "center",
                                                                                alignItems: "center",
                                                                                boxShadow: "0px 2px 6px #AAA"
                                                                            },
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    style: {
                                                                                        position: "absolute",
                                                                                        top: "-28px",
                                                                                        color: "#fff",
                                                                                        fontWeight: "bold",
                                                                                        fontSize: "14px",
                                                                                        fontFamily: "Arial,Helvetica Neue,Helvetica,sans-serif",
                                                                                        padding: "4px",
                                                                                        borderRadius: "4px",
                                                                                        backgroundColor: "#b69225"
                                                                                    },
                                                                                    children: values[index].toFixed(1)
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    style: {
                                                                                        height: "16px",
                                                                                        width: "5px",
                                                                                        backgroundColor: isDragged ? "#b69225" : "#b69225"
                                                                                    }
                                                                                })
                                                                            ]
                                                                        })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "segunda_ciudad",
                                                                className: "form-label",
                                                                children: "Breve rese\xf1a sobre usted"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                                value: html,
                                                                onChange: onChange
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12 col-xl-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "input-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            color: "primary-alta",
                                                            fullwidth: true,
                                                            type: "submit",
                                                            "data-btn": "preview",
                                                            children: "Guardar"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    })
                }),
                showProductModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    show: showProductModal,
                    handleModal: handleProductModal,
                    data: previewData
                })
            ]
        });
    }
    ;
};
CreateNewAreaPerfilMiembro.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewAreaPerfilMiembro.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateNewAreaPerfilMiembro);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1558:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_section_title_layout_01__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1850);
/* harmony import */ var _components_product_layout_01__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1510);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8663);






const LiveExploreArea = ({ data , className , space , id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("rn-live-bidding-area", space === 1 && "ptb--70", className),
        id: id,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                data?.section_title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row mb--30",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_section_title_layout_01__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        ...data.section_title
                    })
                }),
                data?.products && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row g-5",
                    children: data.products.map((prod)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-6 col-xl-3 col-md-6 col-sm-6 col-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_layout_01__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                overlay: true,
                                title: prod.title,
                                slug: prod.slug,
                                latestBid: prod.latestBid,
                                price: prod.price,
                                auction_date: prod.auction_date,
                                likeCount: prod.likeCount,
                                image: prod.images?.[0],
                                authors: prod.authors,
                                bitCount: prod.bitCount
                            })
                        }, prod.id))
                })
            ]
        })
    });
LiveExploreArea.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    id: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        1,
        2
    ]),
    data: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        section_title: _utils_types__WEBPACK_IMPORTED_MODULE_5__/* .SectionTitleType */ .K0,
        products: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_5__/* .ProductType */ .kv).isRequired
    })
};
LiveExploreArea.defaultProps = {
    space: 1
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (LiveExploreArea)));


/***/ })

};
;