"use strict";
exports.id = 1228;
exports.ids = [1228];
exports.modules = {

/***/ 1228:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3715);




const TermsAndConditionsArea = ({ className , space  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("terms-condition-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "offset-lg-2 col-lg-8 ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "condition-wrapper",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "text-center",
                                    children: "T\xc9RMINOS Y CONDICIONES UBUNNIE"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "Actualizaci\xf3n agosto 2024"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: 'Estos T\xe9rminos y Condiciones est\xe1n vigentes hasta agosto de 2024. Revisamos regularmente estos T\xe9rminos y le recomendamos verificar cualquier cambio desde la \xfaltima vez que utiliz\xf3 los servicios de ubunnies.com ("UBUNNIES").'
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "1. Objeto del Sitio Web"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        'El sitio web ubunnies.com, en adelante "UBUNNIES", ofrece un servicio de publicidad para adultos, denominado "Publicidad". Este servicio se rige por las condiciones generales de este Reglamento y las secciones espec\xedficas del Sitio Web. Este documento establece las Condiciones Generales de Uso de UBUNNIES, ubicado en Santa Cruz, Bolivia. Contacto: ',
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            "data-fr-linked": "true",
                                            href: "mailto:contact@ubunnies.com",
                                            children: "contact@ubunnies.com"
                                        }),
                                        "."
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Al utilizar UBUNNIES, los Usuarios declaran haber le\xeddo y comprendido estos T\xe9rminos y Condiciones, acept\xe1ndolos plenamente. Los Usuarios son responsables del contenido que publican y deben proporcionar informaci\xf3n precisa y personal. Si no acepta estos T\xe9rminos, debe abandonar el Sitio y abstenerse de utilizar sus servicios."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "2. Aplicaci\xf3n de las Condiciones"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Este Reglamento se aplica a todos los Usuarios que utilicen el Sitio para publicar, consultar anuncios o interactuar con otros Usuarios."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "3. Requisito de Mayor\xeda de Edad"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "El acceso a UBUNNIES est\xe1 estrictamente prohibido para menores de 18 a\xf1os. Los padres, tutores o representantes legales son responsables de la actividad de menores bajo su cuidado en el Sitio. Al utilizar UBUNNIES, el Usuario:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Garantiza la precisi\xf3n y autenticidad de todos los datos y contenidos publicados, asumiendo plena responsabilidad."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Certifica que tiene al menos 18 a\xf1os."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Se compromete a mantener actualizados sus contenidos."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Las im\xe1genes en los anuncios presentan a personas mayores de edad que han dado su consentimiento para su publicaci\xf3n. No se permitir\xe1n anuncios de menores ni relacionados con menores, respetando las leyes bolivianas. Si UBUNNIES detecta la presencia de menores o falsedades en los anuncios, estos ser\xe1n eliminados sin previo aviso. UBUNNIES puede tomar medidas para proteger a los menores, incluyendo notificar a las autoridades pertinentes."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Los Usuarios que violen gravemente o repetidamente estas Condiciones ser\xe1n expulsados. No se responsabilizar\xe1 por p\xe9rdidas o da\xf1os derivados de la retirada de anuncios, y no habr\xe1 reembolsos por pagos previos. Se recomienda el uso de software de control parental para proteger a los menores del contenido expl\xedcito. Si el contenido dirigido a adultos le resulta inc\xf3modo, le aconsejamos no acceder al Sitio ni utilizar sus servicios."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "4. Uso de UBUNNIES"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "UBUNNIES es exclusivamente para adultos, y al utilizarlo, confirma que tiene al menos 18 a\xf1os y que cumple con las leyes aplicables. El uso del Sitio es gratuito y permite la creaci\xf3n de una cuenta, la publicaci\xf3n y consulta de anuncios, y la interacci\xf3n con otros usuarios, siguiendo las normas del Sitio."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: 'Al hacer clic en "Aceptar" al publicar, autoriza el procesamiento de su foto y datos personales para publicar un anuncio. El contenido publicado ser\xe1 visible para otros Usuarios y, mediante indexaci\xf3n, estar\xe1 disponible en motores de b\xfasqueda y otros sitios web. Nuestro logotipo se a\xf1adir\xe1 como marca de agua en las im\xe1genes cargadas.'
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "UBUNNIES promocionar\xe1 los anuncios en mercados relevantes, pero usted no tiene permiso para usar el Sitio, sus contenidos o anuncios como si fueran su propia base de datos. Est\xe1 prohibido usar el Sitio para fines distintos a los mencionados o realizar actividades que puedan da\xf1ar los servidores de UBUNNIES."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Se compromete a:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "No utilizar medios autom\xe1ticos para copiar, retirar o publicar contenido sin consentimiento previo."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "No recopilar datos personales de terceros sin su consentimiento."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "No eludir las medidas de seguridad del Sitio."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "No introducir malware que afecte el funcionamiento del Sitio."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "No alterar el funcionamiento del Sitio mediante software que afecte su velocidad o funcionamiento."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "6. Responsabilidad del Usuario"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Cada Usuario es responsable de su Cuenta y debe notificar de inmediato a UBUNNIES sobre cualquier actividad anormal o uso no autorizado. Los Usuarios son responsables de los Anuncios y Contenidos publicados, asegurando que sean legales y cumplan con este Reglamento. Espec\xedficamente, los Usuarios no deben publicar:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Contenido difamatorio, violento, amenazante, acosador o abusivo."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Contenido calumnioso o difamatorio."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Contenido relacionado con pornograf\xeda infantil, pedofilia o menores."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Contenido blasfemo o discriminatorio."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Contenido que viole el orden p\xfablico y las buenas costumbres."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Anuncios de pr\xe1cticas violentas o extremas."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Anuncios de venta de f\xe1rmacos, drogas, armas o instrumentos ofensivos."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Anuncios no relacionados con la tem\xe1tica del sitio."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Correo no deseado o spam."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Informaci\xf3n personal de otros Usuarios sin su consentimiento."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Uso indebido de la informaci\xf3n personal de otros Usuarios."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Intento de acceso no autorizado a cuentas o sistemas del Sitio."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Uso del Sitio que pueda da\xf1arlo o perjudicar su funcionamiento."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Intento de eludir las medidas de seguridad del Sitio."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Los Usuarios deben garantizar que los Contenidos no violan derechos de terceros, incluyendo imagen y propiedad intelectual. La carga de prueba de que los Contenidos no est\xe1n protegidos por derechos de autor recae en el Usuario. UBUNNIES puede suspender o cancelar una Cuenta sin previo aviso en caso de violaci\xf3n del Reglamento."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "UBUNNIES proporciona servicios inform\xe1ticos en el Sitio pero no ejerce control sobre los Anuncios o el Contenido, ni act\xfaa como intermediario en transacciones entre Usuarios."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "7. Propiedad Intelectual, Industrial y Derechos de Imagen"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Todos los elementos del sitio web, servicios proporcionados, informaci\xf3n, materiales, estructura, y programas inform\xe1ticos est\xe1n protegidos por derechos de propiedad intelectual e industrial. El Usuario no puede copiar, modificar, distribuir, vender, alquilar ni explotar el contenido del Sitio, excepto su propio contenido. Tampoco puede desensamblar, descompilar o realizar ingenier\xeda inversa del Sitio sin autorizaci\xf3n."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Al publicar un anuncio, el Usuario otorga a UBUNNIES un derecho no exclusivo, mundial, perpetuo, irrevocable, gratuito, sublicenciable y cedible a terceros para explotar el contenido del anuncio (imagen, voz, nombre, fotograf\xeda, descripci\xf3n, perfil) en todos los medios y modalidades."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "UBUNNIES se reserva el derecho de retirar contenidos que violen la ley, estas Condiciones de Uso o los derechos de terceros."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "8. Limitaciones de la Responsabilidad"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "El Usuario asume todos los riesgos relacionados con el uso y la difusi\xf3n de sus datos personales al publicar anuncios. No somos responsables de la veracidad, exactitud ni integridad de los anuncios ni de su conformidad con el orden p\xfablico, las buenas costumbres y la moral, ni de la violaci\xf3n de derechos de propiedad intelectual, industrial o de imagen de terceros."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "No nos hacemos responsables de los da\xf1os directos o indirectos causados por Usuarios, otros Usuarios o terceros en relaci\xf3n con los contenidos, anuncios y el uso del Sitio y servicios. No excluimos la responsabilidad en aquellos casos donde la ley no lo permita."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "No asumimos responsabilidad por p\xe9rdidas o da\xf1os debido a circunstancias fuera de nuestro control, interrupciones o falta de disponibilidad del Sitio o el Servicio, p\xe9rdida de beneficios, negocios, reputaci\xf3n, datos, da\xf1os indirectos o consecuentes."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "No somos parte de los encuentros entre anunciante y cliente, y no somos responsables de da\xf1os derivados de la utilizaci\xf3n y contrataci\xf3n de contenidos y actividades de Usuarios o terceros, ni de la falta de licitud, veracidad o actualidad de los mismos."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "El Sitio y sus afiliados, as\xed como sus sociedades filiales o matrices, gerentes, empleados, agentes o administradores no aceptan ninguna responsabilidad por:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "P\xe9rdidas o da\xf1os fuera de su control razonable."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "P\xe9rdidas o da\xf1os por interrupci\xf3n o falta de disponibilidad del Sitio o del Servicio."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "P\xe9rdidas directas o indirectas de beneficios, negocios, reputaci\xf3n, datos."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "P\xe9rdidas indirectas, especiales o punitivas."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "9. Limitaciones en la Prestaci\xf3n del Servicio"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Este Reglamento se aplica al Sitio y sus servicios tal como est\xe1n en el momento de la aceptaci\xf3n y cualquier modificaci\xf3n posterior."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "No ofrecemos garant\xedas espec\xedficas sobre la idoneidad del Sitio para un prop\xf3sito particular ni prometemos resultados espec\xedficos. No podemos garantizar un funcionamiento ininterrumpido ni libre de defectos t\xe9cnicos. Nos reservamos el derecho de modificar, suspender o interrumpir los servicios del Sitio en cualquier momento, sin previo aviso ni justificaci\xf3n."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Podemos realizar modificaciones en el contenido y servicios del Sitio sin previo aviso."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "10. Pol\xedtica de Reembolsos"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "El uso b\xe1sico de UBUNNIES es gratuito, pero ciertos servicios y funciones premium pueden tener tarifas. Si paga por opciones premium y elimina el anuncio antes de que venza, no habr\xe1 reembolsos. Las tarifas se muestran y cobran en la moneda local, pero podemos facturar en otras divisas."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Las tarifas deben pagarse de inmediato. Si no podemos cobrar la tarifa, el Usuario es responsable de reembolsar cualquier gasto adicional. Si incumple el pago, nos reservamos el derecho de detener servicios adicionales hasta que se realice el pago. Podemos modificar las condiciones y precios de los servicios de pago sin previo aviso. No realizamos reembolsos por los servicios de pago."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Nos reservamos el derecho de realizar cambios en el sitio sin previo aviso, incluyendo cambios de dise\xf1o o funcionalidad. En tales casos, los usuarios no tienen derecho a compensaci\xf3n o reembolso."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Si nuestro proveedor de pagos recibe una solicitud de devoluci\xf3n de fondos, podemos bloquear el perfil del Usuario hasta que se resuelva el problema."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Los Usuarios pueden modificar o eliminar sus anuncios en cualquier momento y solicitar la eliminaci\xf3n de su contenido del sitio web UBUNNIES, lo cual cumpliremos en un plazo de 48 horas por razones t\xe9cnicas."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "11. Indemnizaci\xf3n"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Cada usuario eximir\xe1 a UBUNNIES, sus administradores, empleados y colaboradores de cualquier demanda de compensaci\xf3n, indemnizaci\xf3n o responsabilidad, incluidos los costos legales, relacionadas con denuncias de otros usuarios o terceros en relaci\xf3n con el uso del sitio, servicios relacionados y contenidos publicados o consultados. El usuario reconoce el valor del sitio y se compromete a liberar a UBUNNIES de cualquier responsabilidad."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "13. Ley Aplicable y Jurisdicci\xf3n"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Estos t\xe9rminos se rigen por la legislaci\xf3n boliviana. En caso de disputas, los tribunales del domicilio del usuario ser\xe1n competentes."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "14. Otros"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "La transferencia de derechos y obligaciones del usuario a terceros requiere el consentimiento de UBUNNIES. La divulgaci\xf3n de datos de acceso y contrase\xf1as a terceros est\xe1 prohibida."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "15. Divisibilidad"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        "Si alguna disposici\xf3n de estos t\xe9rminos se considera inv\xe1lida o inaplicable, se separar\xe1 del resto sin afectar la validez de las dem\xe1s disposiciones. Si una disposici\xf3n es ilegal, se modificar\xe1 para que sea v\xe1lida o se reemplazar\xe1 por otra v\xe1lida. Estos t\xe9rminos siguen siendo aplicables despu\xe9s de la cancelaci\xf3n de la cuenta para cl\xe1usulas que requieren persistencia. Cualquier modificaci\xf3n de estos t\xe9rminos debe ser acordada por escrito. Para consultas contactar a: ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            "data-fr-linked": "true",
                                            href: "mailto:contact@ubunnies.com",
                                            children: "contact@ubunnies.com"
                                        }),
                                        " ."
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row mt--50",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "offset-lg-2 col-lg-8"
                    })
                })
            ]
        })
    });
TermsAndConditionsArea.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        1
    ])
};
TermsAndConditionsArea.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TermsAndConditionsArea);


/***/ })

};
;