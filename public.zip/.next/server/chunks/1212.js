"use strict";
exports.id = 1212;
exports.ids = [1212];
exports.modules = {

/***/ 1212:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4574);
/* harmony import */ var _components_product_layout_01__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1510);
/* harmony import */ var _components_product_filter_layout_01__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1967);
/* harmony import */ var _ui_filter_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(637);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8115);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8663);
/* harmony import */ var _components_pagination_02__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5116);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2037);
/* harmony import */ var react_range__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_range__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3715);
/* harmony import */ var _ui_nice_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(388);
/* harmony import */ var _ui_input_range__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3453);















function reducer(state, action) {
    switch(action.type){
        case "SET_PRODUCTS":
            return {
                ...state,
                products: action.payload
            };
        default:
            return state;
    }
}
const STEP = 1;
const MIN = 18;
const MAX = 100;
const POSTS_PER_PAGE = 2;
const ExploreProductAreaHombres = ({ className , space , data  })=>{
    console.log(data);
    const [anuncios, setAnuncios] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data);
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [anunciosList, setAnunciosList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ciudadList, setCiudadList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [etniaList, setEtniaList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [colorCabelloList, setColorCabelloList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [colorOjosList, setColorOjosList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [values, setValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        18,
        100
    ]);
    const [ciudadBuscar, setCiudadBuscar] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [etniaBuscar, setEtniaBuscar] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [colorCabello, setColorCabello] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [colorOjos, setColorOjos] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [edadRango, setEdadRango] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const numberOfPages = Math.ceil(data.products.length / POSTS_PER_PAGE);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
        setAnunciosList(data.products);
    }, []);
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, {
        filterToggle: false,
        products: data.products || [],
        allProducts: data.products || []
    });
    const paginationHandler = (page)=>{
        dispatch({
            type: "SET_PAGE",
            payload: page
        });
        const start = (page - 1) * POSTS_PER_PAGE;
        dispatch({
            type: "SET_PRODUCTS",
            payload: data.products.slice(start, start + POSTS_PER_PAGE)
        });
        document.getElementById("explore-id");
    };
    /*  const itemsToFilter = [...data.products];
  
    const [state, dispatch] = useReducer(reducer, {
        filterToggle: true,
        products: data.products || [],
        allProducts: data.products || [],
        inputs: { price: [0, 100] },
    });
  
    const filterRef = useRef(null);
    const filterHandler = () => {
        dispatch({ type: "FILTER_TOGGLE" });
        if (!filterRef.current) return;
        slideToggle(filterRef.current);
    };

    const numberOfPages = Math.ceil(data.products.length / POSTS_PER_PAGE);
    console.log(state.allProducts);
    console.log(numberOfPages);

    const paginationHandler = (page) => {
        dispatch({ type: "SET_PAGE", payload: page });
        const start = (page - 1) * POSTS_PER_PAGE;
        dispatch({
            type: "SET_PRODUCTS",
            payload: data.products.slice(start, start + POSTS_PER_PAGE),
        });
        document
            .getElementById("explore-id");
    };

    const slectHandler = ({ value }, name) => {
        dispatch({ type: "SET_INPUTS", payload: { [name]: value } });
    };

    const priceHandler = (value) => {
        dispatch({ type: "SET_INPUTS", payload: { price: value } });
    };

    const sortHandler = ({ value }) => {
        const sortedProducts = state.products.sort((a, b) => {
            if (value === "most-liked") {
                return a.likeCount < b.likeCount ? 1 : -1;
            }
            return a.likeCount > b.likeCount ? 1 : -1;
        });
        dispatch({ type: "SET_PRODUCTS", payload: sortedProducts });
    };

    const filterMethods = (item, filterKey, value) => {
        if (value === "all") return false;
        let itemKey = filterKey;
        if (filterKey === "category") {
            itemKey = "categories";
        }
        
        
        if (Array.isArray(item[itemKey])) {
            return !item[itemKey].includes(value);
        }
        if (filterKey === "collection") {
            return item[itemKey].name !== value;
        }
        return item[itemKey] !== value;
    };

    const itemFilterHandler = useCallback(() => {
        let filteredItems = [];

        filteredItems = itemsToFilter.filter((item) => {
            // eslint-disable-next-line no-restricted-syntax
            for (const key in state.inputs) {
                if (filterMethods(item, key, state.inputs[key])) return false;
            }
            return true;
        });
        dispatch({ type: "SET_PRODUCTS", payload: filteredItems });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [state.inputs]);

    useEffect(() => {
        itemFilterHandler();
    }, [itemFilterHandler]);
*/ const obtenerDatos = async ()=>{
        const data2 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getCiudadFiltro");
        const result2 = await data2.json();
        console.log(result2.ciudades);
        setCiudadList(result2.ciudades);
    /*
    const data3 = await fetch(process.env.url + "perfil/getEtniaFiltro")
    const result3 = await data3.json();set
    console.log(result3.etnia);
    setEtniaList(result3.etnia)
    console.log(etniaList);

    const data4 = await fetch(process.env.url + "perfil/getColorCabelloFiltro")
    const result4 = await data4.json();
    console.log(result4.cabello);
    setColorCabelloList(result4.cabello)

    const data5 = await fetch(process.env.url + "perfil/getColorOjosFiltro")
    const result5 = await data5.json();
    console.log(result5.ojos);
    setColorOjosList(result5.ojos)
    */ };
    //obtenerDatos();
    const searcher = (e)=>{
        setSearch(e.target.value);
    };
    ciudadBuscar;
    const selectCiudad = (e)=>{
        console.log(e);
        setCiudadBuscar(e.value);
    };
    const selectEtnia = (e)=>{
        console.log(e);
        setEtniaBuscar(e.value);
    };
    const selectColorCabello = (e)=>{
        console.log(e);
        setColorCabello(e.value);
    };
    const selectColorOjos = (e)=>{
        console.log(e);
        setColorOjos(e.value);
    };
    const buscarEvento = ()=>{
        console.log(ciudadBuscar);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                ciudad: ciudadBuscar
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getAnunciosHombresAllByCiudad", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            //data.products = json.anuncios;
            //            const results = json.anuncios;
            setAnunciosList(json.anuncios);
        }).catch((error)=>toast("Ocurrio un error"));
    };
    //metodo de filtrado 1 
    /*  let results = []
 if(!search)
 {
     results = users
 }else{
      results = users.filter( (dato) =>
      dato.name.toLowerCase().includes(search.toLocaleLowerCase())
  )
 } */ //metodo de filtrado 2   
    //console.log(anuncios);
    const dataOrigin = data.products;
    //console.log(dataOrigin);
    const results = !search ? dataOrigin : dataOrigin.filter((dato)=>dato.nombre.toLowerCase().includes(search.toLocaleLowerCase()));
    //console.log(results);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("rn-product-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row mb--10 align-items-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-lg-2 col-md-6 col-sm-12 filter-select-option mt--0",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "filter-leble",
                                    children: "Ciudad"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    onChange: selectCiudad,
                                    options: ciudadList,
                                    placeholder: "Selecciona",
                                    name: "etnia"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-1"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-lg-1 col-md-6 col-sm-12 filter-select-option mt-10",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "input-box",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                        color: "primary-alta",
                                        fullwidth: true,
                                        type: "button",
                                        "data-btn": "preview",
                                        onClick: buscarEvento,
                                        children: "Buscar"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row g-5",
                    children: anunciosList.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: anunciosList.slice(0, 1000).map((prod)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-5 col-lg-4 col-md-6 col-sm-6 col-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_layout_01__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    overlay: true,
                                    placeBid: !!data.placeBid,
                                    title: prod.nombre,
                                    paquete_activo: prod.paquete_activo,
                                    slug: prod.slug,
                                    latestBid: prod.latestBid,
                                    price: prod.price,
                                    likeCount: prod.likeCount,
                                    auction_date: prod.auction_date,
                                    image: "https://bo.ubunnies.com/backendUbunnie/" + prod.fotografia_portada,
                                    authors: prod.authors,
                                    bitCount: prod.bitCount,
                                    usuario: prod.usuario
                                })
                            }, prod.cod))
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "No hay anuncios para mostrar"
                    })
                })
            ]
        })
    });
};
ExploreProductAreaHombres.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExploreProductAreaHombres);


/***/ })

};
;