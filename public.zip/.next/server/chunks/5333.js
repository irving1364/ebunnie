"use strict";
exports.id = 5333;
exports.ids = [5333];
exports.modules = {

/***/ 40:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8663);




const AuthorProfile = ({ name , image , balance  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "authore-profile",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "thumbnail",
                children: image?.src && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: image.src,
                    alt: image?.alt || name,
                    width: 60,
                    height: 60
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "au-content",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "name",
                        children: name
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "blc",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "value",
                            children: balance
                        })
                    })
                ]
            })
        ]
    });
AuthorProfile.propTypes = {
    name: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
    image: _utils_types__WEBPACK_IMPORTED_MODULE_3__/* .ImageType.isRequired */ .__.isRequired,
    balance: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthorProfile);


/***/ }),

/***/ 6427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);




const FilterButtons = ({ buttons , filterHandler  })=>{
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("all");
    const activeHandler = (filterKey)=>{
        setActive(filterKey);
        filterHandler(filterKey);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "button-group isotop-filter filters-button-group d-flex justify-content-start justify-content-lg-end mt_md--30 mt_sm--30",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                type: "button",
                className: clsx__WEBPACK_IMPORTED_MODULE_3___default()(active === "all" && "is-checked"),
                onClick: ()=>activeHandler("all"),
                children: "All"
            }),
            buttons.map((button)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "button",
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()(button === active && "is-checked"),
                    onClick: ()=>activeHandler(button),
                    children: button
                }, button))
        ]
    });
};
FilterButtons.propTypes = {
    buttons: prop_types__WEBPACK_IMPORTED_MODULE_2___default().arrayOf((prop_types__WEBPACK_IMPORTED_MODULE_2___default().string)),
    filterHandler: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilterButtons);


/***/ }),

/***/ 2341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_anchor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4643);



const HelpMenu = ({ menu  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "help-center-area mainmenu-nav mt--30",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "mainmenu",
            children: menu?.map((nav)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "nav-item",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_anchor__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: "nav-link",
                        path: nav.path,
                        children: [
                            nav?.icon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: nav.icon
                            }),
                            nav.text
                        ]
                    })
                }, nav.id))
        })
    });
HelpMenu.propTypes = {
    menu: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({}))
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HelpMenu);


/***/ }),

/***/ 7952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_offcanvas__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9857);
/* harmony import */ var _components_logo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3697);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);






const MobileMenu = ({ isOpen , onClick , menu , logo  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const irInicio = ()=>{
        router.push({
            pathname: "/"
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_offcanvas__WEBPACK_IMPORTED_MODULE_2__/* .Offcanvas */ .TB, {
        isOpen: isOpen,
        onClick: onClick,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_offcanvas__WEBPACK_IMPORTED_MODULE_2__/* .OffcanvasHeader */ .Us, {
                onClick: onClick,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_logo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    logo: logo
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_offcanvas__WEBPACK_IMPORTED_MODULE_2__/* .OffcanvasBody */ .UT, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "mainmenu",
                        children: [
                            menu?.map((nav)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    id: nav.id,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll__WEBPACK_IMPORTED_MODULE_4__.Link, {
                                        activeClass: "active",
                                        className: "nav-link smoth-animation",
                                        href: `#${nav.path}`,
                                        to: nav.path,
                                        spy: true,
                                        smooth: true,
                                        offset: -50,
                                        duration: 500,
                                        onClick: onClick,
                                        children: nav.text
                                    })
                                }, nav.id)),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                id: 100,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    activeClass: "active",
                                    className: "nav-link smoth-animation",
                                    spy: true,
                                    smooth: true,
                                    offset: -50,
                                    duration: 500,
                                    onClick: irInicio,
                                    children: "Inicio"
                                })
                            }, 100)
                        ]
                    })
                })
            })
        ]
    });
};
MobileMenu.propTypes = {
    isOpen: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool.isRequired),
    onClick: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().func.isRequired),
    menu: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({})),
    logo: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        src: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
        alt: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
    }))
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobileMenu);


/***/ }),

/***/ 7722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_3__);




const SideMenu = ({ menu  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const irInicio = ()=>{
        router.push({
            pathname: "/"
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: "mainmenu-nav",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
            className: "mainmenu list-group",
            children: [
                menu?.map((nav)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: "nav-item",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_scroll__WEBPACK_IMPORTED_MODULE_3__.Link, {
                            activeClass: "active",
                            className: "nav-link smoth-animation",
                            href: `#${nav.path}`,
                            to: nav.path,
                            spy: true,
                            smooth: true,
                            offset: -50,
                            duration: 500,
                            children: [
                                nav?.icon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: nav.icon
                                }),
                                nav.text
                            ]
                        })
                    }, nav.id)),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "nav-item",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        onClick: irInicio,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "feather-home"
                            }),
                            "Inicio"
                        ]
                    })
                })
            ]
        })
    });
};
SideMenu.propTypes = {
    menu: prop_types__WEBPACK_IMPORTED_MODULE_2___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_2___default().shape({}))
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideMenu);


/***/ }),

/***/ 5665:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9306);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_product_layout_01__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1510);




const ProductModal = ({ show , handleModal , data  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default()), {
        className: "rn-popup-modal upload-modal-wrapper",
        show: show,
        onHide: handleModal,
        centered: true,
        children: [
            show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                type: "button",
                className: "btn-close",
                "aria-label": "Close",
                onClick: handleModal,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "feather-x"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Body), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_layout_01__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    overlay: true,
                    disableShareDropdown: true,
                    title: data.name,
                    slug: "/product",
                    latestBid: "6/30",
                    price: {
                        amount: +data.price,
                        currency: "wETH"
                    },
                    likeCount: 300,
                    image: {
                        src: URL.createObjectURL(data.image)
                    },
                    authors: [
                        {
                            name: "Mark Jordan",
                            slug: "/author",
                            image: {
                                src: "/images/client/client-2.png"
                            }
                        },
                        {
                            name: "Farik Shaikh",
                            slug: "/author",
                            image: {
                                src: "/images/client/client-3.png"
                            }
                        },
                        {
                            name: "John Doe",
                            slug: "/author",
                            image: {
                                src: "/images/client/client-5.png"
                            }
                        }
                    ],
                    bitCount: 15
                })
            })
        ]
    });
ProductModal.propTypes = {
    show: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool.isRequired),
    handleModal: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().func.isRequired),
    data: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        image: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({}),
        name: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        price: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
    })
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductModal);


/***/ }),

/***/ 9538:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3715);


const SearchForm = ()=>/*#__PURE__*/ _jsxs("div", {
        className: "input-group",
        children: [
            /*#__PURE__*/ _jsx("input", {
                type: "text",
                placeholder: "Escribe lo que buscas aqui",
                className: "form-control bg-color--2"
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "input-group-append",
                children: /*#__PURE__*/ _jsx(Button, {
                    color: "primary-alta",
                    size: "small",
                    className: "lh-1",
                    children: /*#__PURE__*/ _jsx("i", {
                        className: "feather-search"
                    })
                })
            })
        ]
    });
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SearchForm)));


/***/ }),

/***/ 1850:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);



const SectionTitle = ({ title , align , className , ...rest })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(`section-title text-${align}`, className),
        ...rest,
        children: title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("title mb--0 live-bidding-title"),
            "data-sal-delay": "150",
            "data-sal": "slide-up",
            "data-sal-duration": "800",
            children: title
        })
    });
SectionTitle.propTypes = {
    title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    align: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        "left",
        "right",
        "center"
    ]),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
};
SectionTitle.defaultProps = {
    align: "left"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionTitle);


/***/ }),

/***/ 4921:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: ./src/components/section-title/layout-02/index.jsx
var layout_02 = __webpack_require__(4574);
// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(4643);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/collection/index.jsx




const Collection = ({ title , total_item , image , thumbnails , profile_image , path  })=>/*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
        path: path,
        className: "rn-collection-inner-one",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "collection-wrapper",
            children: [
                image?.src && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "collection-big-thumbnail",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: image.src,
                        alt: image?.alt || "Nft_Profile",
                        width: 507,
                        height: 339
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "collenction-small-thumbnail",
                    children: thumbnails?.map((thumb)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: thumb?.src,
                                alt: thumb?.alt || "Nft_Profile",
                                width: 164,
                                height: 110
                            })
                        }, thumb?.src))
                }),
                profile_image?.src && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "collection-profile",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: profile_image.src,
                        alt: profile_image?.alt || "Nft_Profile",
                        width: 80,
                        height: 80
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "collection-deg",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            className: "title",
                            children: title
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "items",
                            children: [
                                total_item,
                                " items"
                            ]
                        })
                    ]
                })
            ]
        })
    });
Collection.propTypes = {
    title: (external_prop_types_default()).string.isRequired,
    total_item: (external_prop_types_default()).number.isRequired,
    path: (external_prop_types_default()).string.isRequired,
    image: external_prop_types_default().shape({
        src: external_prop_types_default().oneOfType([
            external_prop_types_default().shape(),
            (external_prop_types_default()).string
        ]).isRequired,
        alt: (external_prop_types_default()).string
    }).isRequired,
    thumbnails: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        src: external_prop_types_default().oneOfType([
            external_prop_types_default().shape(),
            (external_prop_types_default()).string
        ]).isRequired,
        alt: (external_prop_types_default()).string
    }).isRequired).isRequired,
    profile_image: external_prop_types_default().shape({
        src: external_prop_types_default().oneOfType([
            external_prop_types_default().shape(),
            (external_prop_types_default()).string
        ]).isRequired,
        alt: (external_prop_types_default()).string
    }).isRequired
};
/* harmony default export */ const components_collection = (Collection);

// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(8663);
;// CONCATENATED MODULE: ./src/containers/collection/layout-02/index.jsx







const TopCollectionArea = ({ className , id , space , data  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_clsx_default()("rn-collection-area", space === 1 && "rn-section-gapTop", space === 2 && "rn-section-gapBottom", className),
        id: id,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row mb--50 align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6 col-md-6 col-sm-6 col-12",
                            children: data?.section_title && /*#__PURE__*/ jsx_runtime_.jsx(layout_02/* default */.Z, {
                                className: "mb--0",
                                ...data.section_title
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6 col-md-6 col-sm-6 col-12 mt_mobile--15",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "view-more-btn text-start text-sm-end",
                                "data-sal-delay": "150",
                                "data-sal": "slide-up",
                                "data-sal-duration": "800",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                                    className: "btn-transparent",
                                    path: "/collection",
                                    children: [
                                        "VIEW ALL",
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "feather feather-arrow-right"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                data?.collections && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row g-5",
                    children: data.collections.map((collection)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            "data-sal": "slide-up",
                            "data-sal-delay": "150",
                            "data-sal-duration": "800",
                            className: "col-lg-6 col-xl-3 col-md-6 col-sm-6 col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_collection, {
                                title: collection.title,
                                total_item: collection.total_item,
                                path: collection.slug,
                                image: collection.image,
                                thumbnails: collection.thumbnails,
                                profile_image: collection.profile_image
                            })
                        }, collection.id))
                })
            ]
        })
    });
TopCollectionArea.propTypes = {
    className: (external_prop_types_default()).string,
    id: (external_prop_types_default()).string,
    space: external_prop_types_default().oneOf([
        1,
        2
    ]),
    data: external_prop_types_default().shape({
        section_title: types/* SectionTitleType */.K0,
        collections: external_prop_types_default().arrayOf(types/* CollectionType */.yl)
    })
};
TopCollectionArea.defaultProps = {
    space: 1
};
/* harmony default export */ const collection_layout_02 = ((/* unused pure expression or super */ null && (TopCollectionArea)));


/***/ }),

/***/ 9070:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 









const CreateNewAreaCiudades = ({ className , space  })=>{
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__/* .useLocalStorage */ ._)("tokens");
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [ciudadesList, setCiudadesList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [perfilList, setPerfilList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    console.log(token);
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
        obtenerDatosPerfil();
    }, []);
    const obtenerDatos = async ()=>{
        const data = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getCiudades");
        const result = await data.json();
        setCiudadesList(result.ciudades);
        console.log(ciudadesList);
        setIsLoad(true);
    };
    const obtenerDatosPerfil = async ()=>{
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data6 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getPerfil", requestOptionsPerfil);
        const result6 = await data6.json();
        setPerfilList(result6.perfil);
        console.log(perfilList);
    };
    const notify = ()=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Your product has submitted");
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    const onSubmit = async (e)=>{
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                token: token,
                cod_primera_ciudad: e.ciudad_base,
                cod_segunda_ciudad: e.primera_ciudad,
                cod_tercera_ciudad: e.segunda_ciudad,
                disponibilidad: e.disponibilidad
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addPerfilCiudades", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                console.log(1);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                console.log(json);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    if (isLoad) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "mt-5", className),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        action: "#",
                        onSubmit: handleSubmit(onSubmit),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row g-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-wrapper-one",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "codigo_pais",
                                                                className: "form-label",
                                                                children: "Ciudad Laboral Actual"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "ciudad_base",
                                                                id: "ciudad_base",
                                                                "aria-label": "Default select example",
                                                                ...register("ciudad_base", {
                                                                    required: "Debe seleccionar un Ciudad Base"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    ciudadesList?.map((ciudad)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            selected: perfilList.cod_primera_ciudad == ciudad.cod,
                                                                            value: ciudad.cod,
                                                                            children: ciudad.ciudad
                                                                        }, ciudad.cod)),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.ciudad_base && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.ciudad_base?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "primera_ciudad",
                                                                children: "Primera Ciudad laboral (opcional)"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "primera_ciudad",
                                                                id: "primera_ciudad",
                                                                "aria-label": "Default select example",
                                                                ...register("primera_ciudad", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    ciudadesList?.map((ciudad)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            selected: perfilList.cod_segunda_ciudad == ciudad.cod,
                                                                            value: ciudad.cod,
                                                                            children: ciudad.ciudad
                                                                        }, ciudad.cod)),
                                                                    ";"
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "segunda_ciudad",
                                                                className: "form-label",
                                                                children: "Segunda Ciudad Laboral (Opcional)"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "segunda_ciudad",
                                                                id: "segunda_ciudad",
                                                                "aria-label": "Default select example",
                                                                ...register("segunda_ciudad", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    ciudadesList?.map((ciudad)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            selected: perfilList.cod_tercera_ciudad == ciudad.cod,
                                                                            value: ciudad.cod,
                                                                            children: ciudad.ciudad
                                                                        }, ciudad.cod)),
                                                                    ";"
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                defaultChecked: parseInt(perfilList.disponibilidad),
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "disponibilidad",
                                                                ...register("disponibilidad", {})
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "disponibilidad",
                                                                children: "Disponibilidad de Viajar"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12 col-xl-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "input-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            color: "primary-alta",
                                                            fullwidth: true,
                                                            type: "submit",
                                                            "data-btn": "preview",
                                                            children: "Guardar"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    })
                }),
                showProductModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    show: showProductModal,
                    handleModal: handleProductModal,
                    data: previewData
                })
            ]
        });
    }
    ;
};
CreateNewAreaCiudades.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewAreaCiudades.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateNewAreaCiudades);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2826:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 









const CreateNewAreaCoordenada = ({ className , space  })=>{
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__/* .useLocalStorage */ ._)("tokens");
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [paisList, setPaisList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [perfilList, setPerfilList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    console.log(token);
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
        obtenerDatosPerfil();
    }, []);
    const obtenerDatos = async ()=>{
        const data = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getPais");
        const result = await data.json();
        setPaisList(result.pais);
        console.log(paisList);
        setIsLoad(true);
    };
    const obtenerDatosPerfil = async ()=>{
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data6 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getPerfil", requestOptionsPerfil);
        const result6 = await data6.json();
        setPerfilList(result6.perfil);
        console.log(perfilList);
    };
    const notify = ()=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Your product has submitted");
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    // This function will be triggered when the file field change
    const imageChange = (e)=>{
        if (e.target.files && e.target.files.length > 0) {
            setSelectedImage(e.target.files[0]);
        }
    };
    const sortHandler = ({ value  })=>{
        setTipoUser(value);
        console.log(tipo_usuario);
    };
    const onSubmit = async (e)=>{
        console.log(e);
        console.log(token);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                token: token,
                cod_pais: e.codigo_pais,
                telefono: e.telefono,
                whatsapp: e.whatsapp,
                telegram: e.telegram,
                user_telegram: e.user_telegram,
                llamada: e.llamada,
                sms: e.sms,
                llamadas_desconocidas: e.llamadas_desconocidas
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addPerfilCoordenada", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                console.log(1);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                console.log(json);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    if (isLoad) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "mt-5", className),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        action: "#",
                        onSubmit: handleSubmit(onSubmit),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row g-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-wrapper-one",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "codigo_pais",
                                                                className: "form-label",
                                                                children: "Codigo Pais"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "codigo_pais",
                                                                id: "codigo_pais",
                                                                "aria-label": "Default select example",
                                                                ...register("codigo_pais", {
                                                                    required: "Debe seleccionar un Codigo de Pais"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    paisList?.map((pais)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                            selected: perfilList.cod_pais == pais.codigo,
                                                                            value: pais.codigo,
                                                                            children: [
                                                                                pais.fone,
                                                                                " - ",
                                                                                pais.iso3,
                                                                                " "
                                                                            ]
                                                                        }, pais.codigo)),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.codigo_pais && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.codigo_pais?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "telefono",
                                                                className: "form-label",
                                                                children: "Telefono"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "telefono",
                                                                placeholder: "Agrega tu numero telefonico",
                                                                defaultValue: perfilList.telefono,
                                                                ...register("telefono", {
                                                                    pattern: {
                                                                        value: /^[0-9]+$/,
                                                                        message: "Ingresa solo numeros"
                                                                    },
                                                                    required: "Telefono es requerida"
                                                                })
                                                            }),
                                                            errors.telefono && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.telefono?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box mt-5",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                defaultChecked: parseInt(perfilList.telegram),
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "telegram",
                                                                ...register("telegram", {})
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "telegram",
                                                                children: "Tienes Telegram?"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "user_telegram",
                                                                className: "form-label",
                                                                children: "Usuario de Telegram"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "user_telegram",
                                                                placeholder: "Agrega su Usuario de Telegram",
                                                                defaultValue: perfilList.user_telegram,
                                                                ...register("user_telegram", {})
                                                            }),
                                                            errors.user_telegram && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.user_telegram?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                defaultChecked: parseInt(perfilList.llamada),
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "llamada",
                                                                ...register("llamada", {})
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "llamada",
                                                                children: "Aceptas Llamadas?"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                defaultChecked: parseInt(perfilList.sms),
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "sms",
                                                                ...register("sms", {})
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "sms",
                                                                children: "Aceptas SMS?"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box ",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                defaultChecked: parseInt(perfilList.whatsapp),
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "whatsapp",
                                                                ...register("whatsapp", {})
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "whatsapp",
                                                                children: "Tienes Whatsapp?"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                defaultChecked: parseInt(perfilList.llamadas_desconocidas),
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "llamadas_desconocidas",
                                                                ...register("llamadas_desconocidas", {})
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "llamadas_desconocidas",
                                                                children: "Aceptas Llamadas Desconocidas?"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12 col-xl-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "input-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            color: "primary-alta",
                                                            fullwidth: true,
                                                            type: "submit",
                                                            "data-btn": "preview",
                                                            children: "Guardar"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    })
                }),
                showProductModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    show: showProductModal,
                    handleModal: handleProductModal,
                    data: previewData
                })
            ]
        });
    }
    ;
};
CreateNewAreaCoordenada.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewAreaCoordenada.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateNewAreaCoordenada);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3942:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 








const CreateNewArea = ({ className , space  })=>{
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    const notify = ()=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Your product has submitted");
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    // This function will be triggered when the file field change
    const imageChange = (e)=>{
        if (e.target.files && e.target.files.length > 0) {
            setSelectedImage(e.target.files[0]);
        }
    };
    const onSubmit = (data, e)=>{
        const { target  } = e;
        const submitBtn = target.localName === "span" ? target.parentElement : target;
        const isPreviewBtn = submitBtn.dataset?.btn;
        setHasImageError(!selectedImage);
        if (isPreviewBtn && selectedImage) {
            setPreviewData({
                ...data,
                image: selectedImage
            });
            setShowProductModal(true);
        }
        if (!isPreviewBtn) {
            notify();
            reset();
            setSelectedImage();
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "rn-section-gapTop", className),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                    action: "#",
                    onSubmit: handleSubmit(onSubmit),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row g-5",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-lg-3 offset-1 ml_md--0 ml_sm--0",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "upload-area",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "upload-formate mb--30",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            className: "title",
                                                            children: "Upload file"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "formate",
                                                            children: "Drag or choose your file to upload"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "brows-file-wrapper",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            name: "file",
                                                            id: "file",
                                                            type: "file",
                                                            className: "inputfile",
                                                            "data-multiple-caption": "{count} files selected",
                                                            multiple: true,
                                                            onChange: imageChange
                                                        }),
                                                        selectedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            id: "createfileImage",
                                                            src: URL.createObjectURL(selectedImage),
                                                            alt: "",
                                                            "data-black-overlay": "6"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                            htmlFor: "file",
                                                            title: "No File Choosen",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                    className: "feather-upload"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "text-center",
                                                                    children: "Choose a File"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                    className: "text-center mt--10",
                                                                    children: [
                                                                        "PNG, GIF, WEBP, MP4 or MP3.",
                                                                        " ",
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                        " Max 1Gb."
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                hasImageError && !selectedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    children: "Image is required"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mt--100 mt_sm--30 mt_md--30 d-none d-lg-block",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                    children: " Note: "
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        " ",
                                                        "Service fee : ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: "2.5%"
                                                        }),
                                                        " "
                                                    ]
                                                }),
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        " ",
                                                        "You will receive :",
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: "25.00 ETH $50,000"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-7",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-wrapper-one",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "name",
                                                                className: "form-label",
                                                                children: "Product Name"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "name",
                                                                placeholder: "e. g. `Digital Awesome Game`",
                                                                ...register("name", {
                                                                    required: "Name is required"
                                                                })
                                                            }),
                                                            errors.name && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.name?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "Discription",
                                                                className: "form-label",
                                                                children: "Discription"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                id: "discription",
                                                                rows: "3",
                                                                placeholder: "e. g. “After purchasing the product you can get item...”",
                                                                ...register("discription", {
                                                                    required: "Discription is required"
                                                                })
                                                            }),
                                                            errors.discription && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.discription?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "price",
                                                                className: "form-label",
                                                                children: "Item Price in $"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "price",
                                                                placeholder: "e. g. `20$`",
                                                                ...register("price", {
                                                                    pattern: {
                                                                        value: /^[0-9]+$/,
                                                                        message: "Please enter a number"
                                                                    },
                                                                    required: "Price is required"
                                                                })
                                                            }),
                                                            errors.price && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.price?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "Size",
                                                                className: "form-label",
                                                                children: "Size"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "size",
                                                                placeholder: "e. g. `Size`",
                                                                ...register("size", {
                                                                    required: "Size is required"
                                                                })
                                                            }),
                                                            errors.size && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.size?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "Propertie",
                                                                className: "form-label",
                                                                children: "Properties"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "propertiy",
                                                                placeholder: "e. g. `Propertie`",
                                                                ...register("propertiy", {
                                                                    required: "Propertiy is required"
                                                                })
                                                            }),
                                                            errors.propertiy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.propertiy?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "Royality",
                                                                className: "form-label",
                                                                children: "Royality"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "royality",
                                                                placeholder: "e. g. `20%`",
                                                                ...register("royality", {
                                                                    required: "Royality is required"
                                                                })
                                                            }),
                                                            errors.royality && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.royality?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4 col-sm-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "putonsale"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "putonsale",
                                                                children: "Put on Sale"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4 col-sm-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "instantsaleprice"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "instantsaleprice",
                                                                children: "Instant Sale Price"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4 col-sm-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20 rn-check-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "rn-check-box-input",
                                                                type: "checkbox",
                                                                id: "unlockpurchased"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "rn-check-box-label",
                                                                htmlFor: "unlockpurchased",
                                                                children: "Unlock Purchased"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12 col-xl-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "input-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            color: "primary-alta",
                                                            fullwidth: true,
                                                            type: "submit",
                                                            "data-btn": "preview",
                                                            onClick: handleSubmit(onSubmit),
                                                            children: "Preview"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12 col-xl-8 mt_lg--15 mt_md--15 mt_sm--15",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "input-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            type: "submit",
                                                            fullwidth: true,
                                                            children: "Submit Item"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mt--100 mt_sm--30 mt_md--30 d-block d-lg-none",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            children: " Note: "
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                " ",
                                                "Service fee : ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    children: "2.5%"
                                                }),
                                                " "
                                            ]
                                        }),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                " ",
                                                "You will receive :",
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    children: "25.00 ETH $50,000"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            }),
            showProductModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                show: showProductModal,
                handleModal: handleProductModal,
                data: previewData
            })
        ]
    });
};
CreateNewArea.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewArea.defaultProps = {
    space: 1
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CreateNewArea)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1971:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6905);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_icons_md__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_icons_md__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 










const CreateNewAreaLenguajes = ({ className , space  })=>{
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__/* .useLocalStorage */ ._)("tokens");
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [lenguajeList, setlenguajeList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
    }, []);
    const obtenerDatos = async ()=>{
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getLenguajes", requestOptionsPerfil);
        const result = await data.json();
        setlenguajeList(result.lenguajes);
        console.log(lenguajeList);
        console.log(result.lenguajes);
        setIsLoad(true);
    };
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    const onSubmit = async (e)=>{
        console.log(e);
        console.log(token);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                token: token,
                idioma: e.idioma,
                nivel: e.nivel
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addlenguaje", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                obtenerDatos();
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    const onDeleteImagen = async (cod)=>{
        console.log(token);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                token: token,
                cod_lenguaje: cod
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/deleteLenguaje", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                obtenerDatos();
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    if (isLoad) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "mt-5", className),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        action: "#",
                        onSubmit: handleSubmit(onSubmit),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row g-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-wrapper-one",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "idioma",
                                                                className: "form-label",
                                                                children: "Idioma"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "idioma",
                                                                id: "idioma",
                                                                "aria-label": "Default select example",
                                                                ...register("idioma", {
                                                                    required: "Debe seleccionar un idioma"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Espa\xf1ol",
                                                                        children: [
                                                                            " ",
                                                                            "Espa\xf1ol",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Ingl\xe9s",
                                                                        children: [
                                                                            " ",
                                                                            "Ingl\xe9s",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: " Portugu\xe9s",
                                                                        children: [
                                                                            " ",
                                                                            " Portugu\xe9s",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Mandar\xedn",
                                                                        children: [
                                                                            " ",
                                                                            "Mandar\xedn",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Franc\xe9s",
                                                                        children: [
                                                                            " ",
                                                                            "Franc\xe9s",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "\xc1rabe",
                                                                        children: [
                                                                            " ",
                                                                            "\xc1rabe",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Ruso",
                                                                        children: [
                                                                            " ",
                                                                            "Ruso",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Alem\xe1n",
                                                                        children: [
                                                                            " ",
                                                                            "Alem\xe1n",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Japon\xe9s",
                                                                        children: [
                                                                            " ",
                                                                            "Japon\xe9s",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Otros",
                                                                        children: [
                                                                            " ",
                                                                            "Otros",
                                                                            " "
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            errors.idioma && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.idioma?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "nivel",
                                                                className: "form-label",
                                                                children: "Nivel"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "nivel",
                                                                id: "nivel",
                                                                "aria-label": "Default select example",
                                                                ...register("nivel", {
                                                                    required: "Debe seleccionar un nivel"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Basico",
                                                                        children: [
                                                                            " ",
                                                                            "Basico",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Promedio",
                                                                        children: [
                                                                            " ",
                                                                            "Promedio",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: " Alto",
                                                                        children: [
                                                                            " ",
                                                                            " Alto",
                                                                            " "
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: "Nativo",
                                                                        children: [
                                                                            " ",
                                                                            "Nativo",
                                                                            " "
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            errors.nivel && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.nivel?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12 col-xl-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "input-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            color: "primary-alta",
                                                            fullwidth: true,
                                                            type: "submit",
                                                            "data-btn": "preview",
                                                            children: "Guardar"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "col-12 mt-5",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "table-title-area d-flex",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                children: "Mis Idiomas"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "box-table table-responsive",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                                className: "table upcoming-projects",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "Codigo"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "Idioma"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "Nivel"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "Eliminar"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                        children: lenguajeList?.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                className: i % 2 === 0 ? "color-light" : "",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: item.cod
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                            children: item.lenguaje
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: item.nivel
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_10__.MdDelete, {
                                                                                                onClick: (event)=>onDeleteImagen(item.cod, event)
                                                                                            })
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            }, item.cod))
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    })
                }),
                showProductModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    show: showProductModal,
                    handleModal: handleProductModal,
                    data: previewData
                })
            ]
        });
    }
    ;
};
CreateNewAreaLenguajes.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewAreaLenguajes.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateNewAreaLenguajes);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3070:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);
/* harmony import */ var _utils_paqueteStore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3655);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _utils_paqueteStore__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _utils_paqueteStore__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 










const CreateNewAreaPerfil = ({ className , space  })=>{
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__/* .useLocalStorage */ ._)("tokens");
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [colorOjosList, setColorOjosList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [colorPeloList, setcolorPeloList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [etniaList, setEtniaList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [nacionalidadList, setNacionalidadList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [tipoScortList, setTipoScortList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [perfilList, setPerfilList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    console.log(token);
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
        obtenerDatosPerfil();
    }, []);
    const obtenerDatos = async ()=>{
        const data = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getColorOjos");
        const result = await data.json();
        setColorOjosList(result.color_ojos);
        const data2 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getColorPelos");
        const result2 = await data2.json();
        setcolorPeloList(result2.color_pelo);
        const data3 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getEtnia");
        const result3 = await data3.json();
        setEtniaList(result3.etnia);
        const data4 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getNacionalidad");
        const result4 = await data4.json();
        setNacionalidadList(result4.nacio);
        const data5 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getTipoScort");
        const result5 = await data5.json();
        setTipoScortList(result5.tipo_scort);
        console.log(colorOjosList);
        console.log(colorPeloList);
        console.log(etniaList);
        console.log(nacionalidadList);
        console.log(tipoScortList);
        setIsLoad(true);
    };
    const obtenerDatosPerfil = async ()=>{
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data6 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getPerfil", requestOptionsPerfil);
        const result6 = await data6.json();
        setPerfilList(result6.perfil);
        console.log(perfilList);
    };
    const notify = ()=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Your product has submitted");
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    const sortHandler = ({ value  })=>{
        setTipoUser(value);
        console.log(tipo_usuario);
    };
    const onSubmit = async (e)=>{
        console.log(e);
        console.log(token);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                token: token,
                nombre: e.nombre,
                cod_tipo_scort: e.tipo,
                edad: e.edad,
                slogan: e.eslogan,
                cod_etnia: e.etnia,
                cod_nacionalidad: e.nacionalidad,
                cod_color_pelo: e.color_pelo,
                longitud_pelo: e.longitud_pelo,
                cod_color_ojos: e.color_ojos,
                talla_senos: e.talla_senos,
                tipo_senos: e.tipo_senos,
                talla: e.talla,
                peso: e.peso,
                miembro: e.miembro,
                miembro_tamano: e.longitud_miembro,
                contextura: e.contextura,
                fuma: e.fuma,
                bebe: e.bebe,
                piercing: e.piercing,
                tatto: e.tatto
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addPerfil", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                console.log(1);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                console.log(json);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    if (isLoad) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "mt-5", className),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        action: "#",
                        onSubmit: handleSubmit(onSubmit),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row g-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-wrapper-one",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "edad",
                                                                className: "form-label",
                                                                children: "Nombre"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "nombre",
                                                                placeholder: "Agrega tu Nombre",
                                                                defaultValue: perfilList.nombre,
                                                                ...register("nombre", {
                                                                    required: "Su Nombre es requerida"
                                                                })
                                                            }),
                                                            errors.nombre && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.nombre?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "tipo",
                                                                className: "form-label",
                                                                children: "Tipo de Escort"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "tipo",
                                                                id: "tipo",
                                                                "aria-label": "Default select example",
                                                                ...register("tipo", {
                                                                    required: "Debe seleccionar un tipo de Escort"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    tipoScortList?.map((tipo)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                            selected: perfilList.cod_tipo_scort == tipo.cod,
                                                                            value: tipo.cod,
                                                                            children: [
                                                                                tipo.tipo_scort,
                                                                                " "
                                                                            ]
                                                                        }, tipo.cod)),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.tipo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.tipo?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "edad",
                                                                className: "form-label",
                                                                children: "Edad"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "edad",
                                                                placeholder: "Agrega tu edad",
                                                                type: "number",
                                                                defaultValue: perfilList.edad,
                                                                ...register("edad", {
                                                                    pattern: {
                                                                        value: /^[0-9]+$/,
                                                                        message: "Ingresa solo numeros"
                                                                    },
                                                                    required: "Edad es requerida",
                                                                    min: {
                                                                        value: 18,
                                                                        message: "El valor minimo permitido es 18"
                                                                    },
                                                                    max: {
                                                                        value: 100,
                                                                        message: "El valor maximo permitido es 100"
                                                                    }
                                                                })
                                                            }),
                                                            errors.edad && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.edad?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "eslogan",
                                                                className: "form-label",
                                                                children: "Eslogan"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "eslogan",
                                                                defaultValue: perfilList.slogan,
                                                                placeholder: "Agrega tu eslogan de preferencia`",
                                                                ...register("eslogan", {})
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "etnia",
                                                                className: "form-label",
                                                                children: "Su de etnia"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "etnia",
                                                                id: "etnia",
                                                                "aria-label": "Default select example",
                                                                ...register("etnia", {
                                                                    required: "Debe seleccionar la etnia"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    etniaList?.map((etnias)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                            selected: perfilList.cod_etnia == etnias.cod,
                                                                            value: etnias.cod,
                                                                            children: [
                                                                                etnias.etnia,
                                                                                " "
                                                                            ]
                                                                        })),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.etnia && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.etnia?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "nacionalidad",
                                                                className: "form-label",
                                                                children: "Su Nacionalidad"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "nacionalidad",
                                                                id: "nacionalidad",
                                                                "aria-label": "Default select example",
                                                                ...register("nacionalidad", {
                                                                    required: "Debe seleccionar su Nacionalidad"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    nacionalidadList?.map((nacionalidad)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                            selected: perfilList.cod_nacionalidad == nacionalidad.cod,
                                                                            value: nacionalidad.cod,
                                                                            children: [
                                                                                nacionalidad.PAIS_NAC,
                                                                                " - ",
                                                                                nacionalidad.ISO_NAC,
                                                                                " "
                                                                            ]
                                                                        })),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.nacionalidad && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.nacionalidad?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "color_ojos",
                                                                className: "form-label",
                                                                children: "Su color de ojos"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                className: "input-box pb--20",
                                                                name: "color_ojos",
                                                                id: "color_ojos",
                                                                "aria-label": "Default select example",
                                                                ...register("color_ojos", {
                                                                    required: "Color de ojos es requerida"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    colorOjosList?.map((color_ojo)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                            selected: perfilList.cod_color_ojos == color_ojo.cod,
                                                                            value: color_ojo.cod,
                                                                            children: [
                                                                                color_ojo.color,
                                                                                " "
                                                                            ]
                                                                        })),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.color_ojos && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.color_ojos?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "color_pelo",
                                                                className: "form-label",
                                                                children: "Su color de Cabello"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "color_pelo",
                                                                id: "color_pelo",
                                                                "aria-label": "Default select example",
                                                                ...register("color_pelo", {
                                                                    required: "Color de cabello es requerida"
                                                                }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    colorPeloList?.map((color_pelo)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                            selected: perfilList.cod_color_pelo == color_pelo.cod,
                                                                            value: color_pelo.cod,
                                                                            children: [
                                                                                color_pelo.color_pelo,
                                                                                " "
                                                                            ]
                                                                        })),
                                                                    ";"
                                                                ]
                                                            }),
                                                            errors.color_pelo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.color_pelo?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "longitud_pelo",
                                                                className: "form-label",
                                                                children: "Logintud de su Cabello (cm)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "longitud_pelo",
                                                                defaultValue: perfilList.longitud_pelo,
                                                                placeholder: "Ingrese la logintud de su Cabello",
                                                                ...register("longitud_pelo", {
                                                                    pattern: {
                                                                        value: /^[0-9]+$/,
                                                                        message: "Ingresa solo numeros"
                                                                    }
                                                                })
                                                            }),
                                                            errors.longitud_pelo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.longitud_pelo?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contextura",
                                                                className: "form-label",
                                                                children: "Su Contextura"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "contextura",
                                                                id: "contextura",
                                                                "aria-label": "Default select example",
                                                                ...register("contextura", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.contextura == "1",
                                                                        value: "1",
                                                                        children: "Delgada "
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.contextura == "2",
                                                                        value: "2",
                                                                        children: "Media"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.contextura == "3",
                                                                        value: "3",
                                                                        children: "Gruesa"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "talla",
                                                                className: "form-label",
                                                                children: "Su Estatura (cm)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "talla",
                                                                defaultValue: perfilList.talla,
                                                                placeholder: "Ingrese su Estatura, solo numero",
                                                                ...register("talla", {
                                                                    pattern: {
                                                                        value: /^[0-9]+$/,
                                                                        message: "Ingresa solo numeros"
                                                                    }
                                                                })
                                                            }),
                                                            errors.talla && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.talla?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "peso",
                                                                className: "form-label",
                                                                children: "Su Peso (kl)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "peso",
                                                                defaultValue: perfilList.peso,
                                                                placeholder: "Ingrese su Peso",
                                                                ...register("peso", {
                                                                    pattern: {
                                                                        value: /^[0-9]+$/,
                                                                        message: "Ingresa solo numeros"
                                                                    }
                                                                })
                                                            }),
                                                            errors.longitud_pelo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.longitud_pelo?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "tipo_senos",
                                                                className: "form-label",
                                                                children: "Tipo de Senos"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "tipo_senos",
                                                                id: "tipo_senos",
                                                                "aria-label": "Default select example",
                                                                ...register("tipo_senos", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.tipo_senos == "1",
                                                                        value: "1",
                                                                        children: "Naturales"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.tipo_senos == "2",
                                                                        value: "2",
                                                                        children: "Operados"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.tipo_senos == "0",
                                                                        value: "0",
                                                                        children: "No aplica"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "talla_senos",
                                                                className: "form-label",
                                                                children: "Talla de Senos"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "talla_senos",
                                                                id: "tipo_talla_senossenos",
                                                                "aria-label": "Default select example",
                                                                ...register("talla_senos", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "A",
                                                                        value: "A",
                                                                        children: "A"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "B",
                                                                        value: "B",
                                                                        children: "B"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "C",
                                                                        value: "C",
                                                                        children: "C"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "D",
                                                                        value: "D",
                                                                        children: "D"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "DD",
                                                                        value: "DD",
                                                                        children: "DD"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "F",
                                                                        value: "F",
                                                                        children: "F"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "FF",
                                                                        value: "FF",
                                                                        children: "FF"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "G",
                                                                        value: "G",
                                                                        children: "G"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "H",
                                                                        value: "H",
                                                                        children: "H"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.talla_senos == "J",
                                                                        value: "J",
                                                                        children: "J"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "fuma",
                                                                className: "form-label",
                                                                children: "Usted Fuma?"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "fuma",
                                                                id: "fuma",
                                                                "aria-label": "Default select example",
                                                                ...register("fuma", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.fuma == "1",
                                                                        value: "1",
                                                                        children: "No "
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.fuma == "2",
                                                                        value: "2",
                                                                        children: "Si"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.fuma == "3",
                                                                        value: "3",
                                                                        children: "Eventualmente"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "bebe",
                                                                className: "form-label",
                                                                children: "Usted Toma?"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "bebe",
                                                                id: "bebe",
                                                                "aria-label": "Default select example",
                                                                ...register("bebe", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.bebe == "1",
                                                                        value: "1",
                                                                        children: "No "
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.bebe == "2",
                                                                        value: "2",
                                                                        children: "Si"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.bebe == "3",
                                                                        value: "3",
                                                                        children: "Eventualmente"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "piercing",
                                                                className: "form-label",
                                                                children: "Posees Piercing"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "piercing",
                                                                id: "piercing",
                                                                "aria-label": "Default select example",
                                                                ...register("piercing", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.piercing == "1",
                                                                        value: "1",
                                                                        children: "Si "
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.piercing == "2",
                                                                        value: "2",
                                                                        children: "No"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "tatto",
                                                                className: "form-label",
                                                                children: "Posees Tattoos"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "tatto",
                                                                id: "tatto",
                                                                "aria-label": "Default select example",
                                                                ...register("tatto", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.tatto == "1",
                                                                        value: "1",
                                                                        children: "Si "
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.tatto == "2",
                                                                        value: "2",
                                                                        children: "No"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "miembro",
                                                                className: "form-label",
                                                                children: "Posees Miembro"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                name: "miembro",
                                                                id: "miembro",
                                                                "aria-label": "Default select example",
                                                                ...register("miembro", {}),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "",
                                                                        children: "Debe seleccionar una opcion"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.miembro == "1",
                                                                        value: "1",
                                                                        children: "Si "
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        selected: perfilList.miembro == "2",
                                                                        value: "2",
                                                                        children: "No"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "input-box pb--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "longitud_miembro",
                                                                className: "form-label",
                                                                children: "Logintud de su Miembro"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "longitud_miembro",
                                                                defaultValue: perfilList.miembro_tamano,
                                                                placeholder: "Ingrese la logintud de su Cabello",
                                                                ...register("longitud_miembro", {
                                                                    pattern: {
                                                                        value: /^[0-9]+$/,
                                                                        message: "Ingresa solo numeros"
                                                                    }
                                                                })
                                                            }),
                                                            errors.longitud_miembro && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                children: errors.longitud_miembro?.message
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-12 col-xl-4 mt_lg--15 mt_md--15 mt_sm--15",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "input-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            type: "submit",
                                                            fullwidth: true,
                                                            children: "Guardar"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    })
                }),
                showProductModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    show: showProductModal,
                    handleModal: handleProductModal,
                    data: previewData
                })
            ]
        });
    }
    ;
};
CreateNewAreaPerfil.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewAreaPerfil.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateNewAreaPerfil);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3800:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);
/* harmony import */ var react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2040);
/* harmony import */ var react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 










const CreateNewAreaSobreMi = ({ className , space  })=>{
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__/* .useLocalStorage */ ._)("tokens");
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [sobreMi, setSobreMi] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [perfilList, setPerfilList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [html, setHtml] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    function onChange(e) {
        setHtml(e.target.value);
    }
    console.log(token);
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatos();
        obtenerDatosPerfil();
    }, []);
    const obtenerDatos = async ()=>{
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getSobreMi", requestOptionsPerfil);
        const result = await data.json();
        setHtml(result.sobre_mi.sobre_mi);
        console.log(sobreMi);
        setIsLoad(true);
    };
    const obtenerDatosPerfil = async ()=>{
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data6 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getPerfil", requestOptionsPerfil);
        const result6 = await data6.json();
        setPerfilList(result6.perfil);
        console.log(perfilList);
    };
    const notify = ()=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Your product has submitted");
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    const onSubmit = async (e)=>{
        console.log(e);
        console.log(token);
        var requestOptions = {
            method: "POST",
            body: JSON.stringify({
                token: token,
                sobre_mi: html
            })
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addSobreMi", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                console.log(1);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                console.log(json);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "mt-5", className),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                    action: "#",
                    onSubmit: handleSubmit(onSubmit),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "row g-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "form-wrapper-one",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-md-12",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "input-box pb--20",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                            htmlFor: "codigo_pais",
                                                            className: "form-label",
                                                            children: "Informaci\xf3n Sobre Mi"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_simple_wysiwyg__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                            value: html,
                                                            onChange: onChange
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-md-12 col-xl-4",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "input-box",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        color: "primary-alta",
                                                        fullwidth: true,
                                                        type: "submit",
                                                        "data-btn": "preview",
                                                        children: "Guardar"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    })
                })
            }),
            showProductModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                show: showProductModal,
                handleModal: handleProductModal,
                data: previewData
            })
        ]
    });
};
CreateNewAreaSobreMi.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewAreaSobreMi.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateNewAreaSobreMi);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5419:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4574);
/* harmony import */ var _components_product_layout_01__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1510);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8115);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_filter_buttons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6427);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8663);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const ExploreProductArea = ({ className , space , data , id  })=>{
    const filters = [
        ...new Set((0,_utils_methods__WEBPACK_IMPORTED_MODULE_7__.flatDeep)(data?.products.map((item)=>item.categories) || []))
    ];
    const [products, setProducts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setProducts(data?.products);
    }, [
        data?.products
    ]);
    const filterHandler = (filterKey)=>{
        const prods = data?.products ? [
            ...data.products
        ] : [];
        if (filterKey === "all") {
            setProducts(data?.products);
            return;
        }
        const filterProds = prods.filter((prod)=>prod.categories.includes(filterKey));
        setProducts(filterProds);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("rn-product-area masonary-wrapper-activation", space === 1 && "rn-section-gapTop", space === 2 && "rn-section-gapBottom", className),
        id: id,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row gx-5 align-items-center mb--60",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-4",
                            children: data?.section_title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                className: "mb--0",
                                disableAnimation: true,
                                ...data.section_title
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_filter_buttons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                buttons: filters,
                                filterHandler: filterHandler
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-lg-12",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        layout: true,
                        className: "isotope-list item-4",
                        children: products?.slice(0, 8)?.map((prod)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("grid-item"),
                                layout: true,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_layout_01__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    placeBid: !!data.placeBid,
                                    title: prod.title,
                                    slug: prod.slug,
                                    latestBid: prod.latestBid,
                                    price: prod.price,
                                    likeCount: prod.likeCount,
                                    image: prod.images?.[0],
                                    authors: prod.authors,
                                    bitCount: prod.bitCount
                                })
                            }, prod.id))
                    })
                })
            ]
        })
    });
};
ExploreProductArea.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1,
        2
    ]),
    id: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    data: prop_types__WEBPACK_IMPORTED_MODULE_2___default().shape({
        section_title: _utils_types__WEBPACK_IMPORTED_MODULE_9__/* .SectionTitleType */ .K0,
        products: prop_types__WEBPACK_IMPORTED_MODULE_2___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_9__/* .ProductType */ .kv),
        placeBid: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool)
    })
};
ExploreProductArea.defaultProps = {
    space: 1
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ExploreProductArea)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6762:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: ./src/components/ui/slider/index.jsx
var slider = __webpack_require__(8179);
// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(8663);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(4643);
// EXTERNAL MODULE: ./src/components/ui/countdown/layout-02/index.jsx
var layout_02 = __webpack_require__(908);
// EXTERNAL MODULE: ./src/components/ui/client-avatar/index.jsx
var client_avatar = __webpack_require__(2542);
// EXTERNAL MODULE: ./src/components/ui/button/index.jsx
var ui_button = __webpack_require__(3715);
// EXTERNAL MODULE: ./src/components/modals/placebid-modal/index.jsx
var placebid_modal = __webpack_require__(3709);
;// CONCATENATED MODULE: ./src/containers/hero/layout-08/slide.jsx










const SingleSlide = ({ image , title , path , description , authors , bitCount , auction_date , award_image  })=>{
    const [showBidModal, setShowBidModal] = (0,external_react_.useState)(false);
    const handleBidModal = ()=>{
        setShowBidModal((prev)=>!prev);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            image?.src && /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "slider-bg",
                src: image.src,
                alt: "Slider BG",
                quality: 100,
                priority: true,
                fill: true,
                sizes: "100vw",
                style: {
                    objectFit: "cover"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "rn-banner-wrapper g-5 row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-4 col-lg-12 col-12 order-3 order-xl-1 order-sm-1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                            path: path,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "title pl--30",
                                dangerouslySetInnerHTML: {
                                    __html: title
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-6 col-lg-12 col-12 order-2 order-xl-2 order-sm-2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "item-description",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: description
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "product-share-wrapper",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "profile-share",
                                            children: [
                                                authors?.map((author)=>/*#__PURE__*/ jsx_runtime_.jsx(client_avatar/* default */.Z, {
                                                        slug: author.slug,
                                                        name: author.name,
                                                        image: author.image
                                                    }, author.name)),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_anchor/* default */.Z, {
                                                    className: "more-author-text",
                                                    path: path,
                                                    children: [
                                                        bitCount,
                                                        "+ Place Bit."
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(layout_02["default"], {
                                            date: auction_date
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* default */.Z, {
                                    color: "primary-alta",
                                    className: "mt--35",
                                    onClick: handleBidModal,
                                    children: "Place a Bid"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-2 col-lg-12 col-12 order-1 order-xl-3 order-sm-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "img-thumb-award d-flex justify-content-center",
                            children: award_image?.src && /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: award_image.src,
                                alt: "Nft_Profile",
                                width: 130,
                                height: 130
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(placebid_modal/* default */.Z, {
                show: showBidModal,
                handleModal: handleBidModal
            })
        ]
    });
};
SingleSlide.propTypes = {
    title: (external_prop_types_default()).string,
    path: (external_prop_types_default()).string,
    description: (external_prop_types_default()).string,
    authors: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        name: (external_prop_types_default()).string,
        slug: (external_prop_types_default()).string,
        image: types/* ImageType */.__
    })),
    bitCount: (external_prop_types_default()).number,
    auction_date: (external_prop_types_default()).string,
    image: types/* ImageType */.__,
    award_image: types/* ImageType */.__
};
/* harmony default export */ const slide = (SingleSlide);

;// CONCATENATED MODULE: ./src/containers/hero/layout-08/index.jsx





const HeroArea = ({ data  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "rn-banner-area",
        children: data?.banners && /*#__PURE__*/ jsx_runtime_.jsx(slider/* default */.Z, {
            options: {
                dots: true
            },
            className: "slider-activation-banner-4 game-banner-short-slick-wrapper slick-arrow-style-one rn-slick-dot-style",
            children: data.banners.map((banner)=>/*#__PURE__*/ jsx_runtime_.jsx(slider/* SliderItem */.w, {
                    className: "slider-style-7 border-radious-none pt--150 pb--190 pt_sm--70 pb_sm--70",
                    "data-black-overlay": "6",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(slide, {
                        title: banner.title,
                        path: banner.path,
                        description: banner.description,
                        authors: banner.authors,
                        bitCount: banner.bitCount,
                        auction_date: banner.auction_date,
                        image: banner.image,
                        award_image: banner.award_image
                    })
                }, banner.id))
        })
    });
HeroArea.propTypes = {
    data: external_prop_types_default().shape({
        banners: external_prop_types_default().arrayOf(external_prop_types_default().shape({
            id: types/* IDType */.iJ,
            title: (external_prop_types_default()).string,
            path: (external_prop_types_default()).string,
            description: (external_prop_types_default()).string,
            authors: external_prop_types_default().arrayOf(external_prop_types_default().shape({
                name: (external_prop_types_default()).string,
                slug: (external_prop_types_default()).string,
                image: types/* ImageType */.__
            })),
            bitCount: (external_prop_types_default()).number,
            auction_date: (external_prop_types_default()).string,
            image: types/* ImageType */.__,
            award_image: types/* ImageType */.__
        })).isRequired
    }).isRequired
};
/* harmony default export */ const layout_08 = ((/* unused pure expression or super */ null && (HeroArea)));


/***/ }),

/***/ 3783:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: ./src/components/section-title/layout-02/index.jsx
var layout_02 = __webpack_require__(4574);
// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(4643);
// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(8663);
;// CONCATENATED MODULE: ./src/components/service/index.jsx




const Service = ({ title , subtitle , path , description , image  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        "data-sal": "slide-up",
        "data-sal-delay": "150",
        "data-sal-duration": "800",
        className: "rn-service-one color-shape-7",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "inner",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "icon",
                        children: image?.src && // eslint-disable-next-line @next/next/no-img-element
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: image.src,
                            alt: image?.alt || title
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "subtitle",
                        children: subtitle
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "content",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "title",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                    path: path,
                                    children: title
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "description",
                                children: description
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                className: "read-more-button",
                                path: path,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "feather-arrow-right"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                className: "over-link",
                path: path,
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "visually-hidden",
                    children: "Click here to read more"
                })
            })
        ]
    });
Service.propTypes = {
    title: (external_prop_types_default()).string.isRequired,
    subtitle: (external_prop_types_default()).string.isRequired,
    path: (external_prop_types_default()).string.isRequired,
    description: (external_prop_types_default()).string.isRequired,
    image: types/* ImageType */.__
};
/* harmony default export */ const service = (Service);

;// CONCATENATED MODULE: ./src/containers/services/layout-01/index.jsx






const ServiceArea = ({ className , id , space , data  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_clsx_default()("rn-service-area", space === 1 && "rn-section-gapTop", space === 2 && "pb--70", className),
        id: id,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                data?.section_title && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 mb--50",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(layout_02/* default */.Z, {
                            ...data.section_title
                        })
                    })
                }),
                data?.items && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row g-5",
                    children: data.items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xxl-3 col-lg-4 col-md-6 col-sm-6 col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(service, {
                                title: item.title,
                                subtitle: item.subtitle,
                                path: item.path,
                                description: item.description,
                                image: item.images[0]
                            })
                        }, item.id))
                })
            ]
        })
    });
ServiceArea.propTypes = {
    className: (external_prop_types_default()).string,
    id: (external_prop_types_default()).string,
    space: external_prop_types_default().oneOf([
        1,
        2
    ]),
    data: external_prop_types_default().shape({
        section_title: types/* SectionTitleType */.K0,
        items: external_prop_types_default().arrayOf(types/* ItemType */.qG)
    })
};
ServiceArea.defaultProps = {
    space: 1
};
/* harmony default export */ const layout_01 = ((/* unused pure expression or super */ null && (ServiceArea)));


/***/ }),

/***/ 8286:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8519);
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(web3__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_search_form_layout_03__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9538);
/* harmony import */ var _ui_anchor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4643);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_color_switcher__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4617);
/* harmony import */ var _ui_burger_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6735);
/* harmony import */ var _components_search_form_layout_02__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5353);
/* harmony import */ var _components_menu_mobile_menu_02__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7952);
/* harmony import */ var _components_user_dropdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6067);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5009);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2512);
/* harmony import */ var _components_user_log_dropdown__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6360);
/* harmony import */ var _data_general_menu_02_json__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6098);
/* harmony import */ var _data_general_menu_05_json__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2115);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_color_switcher__WEBPACK_IMPORTED_MODULE_6__, _components_user_dropdown__WEBPACK_IMPORTED_MODULE_10__]);
([_components_color_switcher__WEBPACK_IMPORTED_MODULE_6__, _components_user_dropdown__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable no-console */ 













// Demo Data


const TopBarArea = ()=>{
    const { search , searchHandler  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useFlyoutSearch */ .Dm)();
    const { offcanvas , offcanvasHandler  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useOffcanvas */ .vI)();
    // const { authenticate, isAuthenticated } = useMoralis();
    console.log((0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_12__/* .useLocalStorage */ ._)("usuario"));
    const [load, setLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [usuario, setUsuario] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_12__/* .useLocalStorage */ ._)("usuario");
    const [tipo_usuario, setTipoUsuario] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_12__/* .useLocalStorage */ ._)("tipo_usuario");
    const [logueado, setLogueado] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLoad(true);
    }, []);
    const [isAuthenticated, setIsAuthenticated] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [ethBalance, setEthBalance] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const detectCurrentProvider = ()=>{
        let provider;
        if (window.ethereum) {
            provider = window.ethereum;
        } else if (window.web3) {
            provider = window.web3.currentProvider;
        } else {
            console.log("Non-ethereum browser detected. You should install Metamask");
        }
        return provider;
    };
    const onConnect = async ()=>{
        try {
            const currentProvider = detectCurrentProvider();
            if (currentProvider) {
                await currentProvider.request({
                    method: "eth_requestAccounts"
                });
                const web3 = new (web3__WEBPACK_IMPORTED_MODULE_2___default())(currentProvider);
                const userAccount = await web3.eth.getAccounts();
                const account = userAccount[0];
                const getEthBalance = await web3.eth.getBalance(account);
                setEthBalance(getEthBalance);
                setIsAuthenticated(true);
            }
        } catch (err) {
            console.log(err);
        }
    };
    const onDisconnect = ()=>{
        setIsAuthenticated(false);
    };
    if (load) {
        console.log(usuario);
        if (usuario == "undefined") {
            setLogueado(true);
        }
        console.log(logueado);
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "rn-top-bar-area",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "contact-area",
                        children: [
                            usuario && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "setting-option header-btn",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "icon-box",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        color: "primary-alta",
                                        className: "connectBtn",
                                        size: "small",
                                        onClick: onConnect,
                                        children: "AN\xdaNCIATE"
                                    })
                                })
                            }),
                            usuario != undefined && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "setting-option rn-icon-list user-account",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_user_dropdown__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    onDisconnect: onDisconnect,
                                    ethBalance: ethBalance
                                })
                            }),
                            usuario === undefined && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "setting-option rn-icon-list user-account",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_user_log_dropdown__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "setting-option mobile-menu-bar ml--5 d-block d-lg-none",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "hamberger icon-box",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_burger_button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        onClick: offcanvasHandler
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                id: "my_switcher",
                                className: "my_switcher setting-option",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_color_switcher__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                            })
                        ]
                    })
                }),
                tipo_usuario == "2" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_menu_mobile_menu_02__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    menu: _data_general_menu_02_json__WEBPACK_IMPORTED_MODULE_14__,
                    isOpen: offcanvas,
                    onClick: offcanvasHandler,
                    logo: [
                        {
                            src: "/logo.png"
                        },
                        {
                            src: "/logo-negro.png"
                        }
                    ]
                }),
                tipo_usuario == "3" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_menu_mobile_menu_02__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    menu: _data_general_menu_05_json__WEBPACK_IMPORTED_MODULE_15__,
                    isOpen: offcanvas,
                    onClick: offcanvasHandler,
                    logo: [
                        {
                            src: "/logo.png"
                        },
                        {
                            src: "/logo-negro.png"
                        }
                    ]
                })
            ]
        });
    }
    ;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopBarArea);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3123:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4574);
/* harmony import */ var _components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(491);
/* harmony import */ var _ui_nice_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(388);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8663);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8115);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_8__);









const TopSellerArea = ({ className , space , id , data  })=>{
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("1 day");
    const [sellers, setSellers] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const changeHandler = (item)=>{
        setCurrent(item.value);
    };
    const filterHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        const allSellers = data.sellers;
        const filterdSellers = allSellers.filter((seller)=>(0,_utils_methods__WEBPACK_IMPORTED_MODULE_8__.slugify)(seller.top_since) === (0,_utils_methods__WEBPACK_IMPORTED_MODULE_8__.slugify)(current));
        setSellers(filterdSellers);
    }, [
        current,
        data.sellers
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        filterHandler();
    }, [
        filterHandler
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("rn-top-top-seller-area nice-selector-transparent", space === 1 && "rn-section-gapTop", space === 2 && "rn-section-gapBottom", space === 3 && "pt--50", className),
        id: id,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row mb--30",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-12 justify-sm-center d-flex",
                        children: [
                            data?.section_title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_section_title_layout_02__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                ...data.section_title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_nice_select__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                options: [
                                    {
                                        value: "1 day",
                                        text: "1 day"
                                    },
                                    {
                                        value: "7 Day's",
                                        text: "7 Day's"
                                    },
                                    {
                                        value: "15 Day's",
                                        text: "15 Day's"
                                    },
                                    {
                                        value: "30 Day's",
                                        text: "30 Day's"
                                    }
                                ],
                                defaultCurrent: 0,
                                name: "sellerSort",
                                onChange: changeHandler
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row justify-sm-center g-5 top-seller-list-wrapper",
                    children: sellers.map((seller)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-5 col-lg-3 col-md-4 col-sm-6 top-seller-list",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                name: seller.name,
                                total_sale: seller.total_sale,
                                slug: seller.slug,
                                image: seller.image
                            })
                        }, seller.id))
                })
            ]
        })
    });
};
TopSellerArea.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    id: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1,
        2,
        3
    ]),
    data: prop_types__WEBPACK_IMPORTED_MODULE_2___default().shape({
        section_title: _utils_types__WEBPACK_IMPORTED_MODULE_7__/* .SectionTitleType */ .K0,
        sellers: prop_types__WEBPACK_IMPORTED_MODULE_2___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_7__/* .SellerType */ .Df)
    })
};
TopSellerArea.defaultProps = {
    space: 1
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (TopSellerArea)));


/***/ }),

/***/ 5240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer_02)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: ./src/components/logo/index.jsx
var logo = __webpack_require__(3697);
;// CONCATENATED MODULE: ./src/data/general/footer-02.json
const footer_02_namespaceObject = JSON.parse('{"j":[{"src":"/logo.png","alt":"logo"}],"M":"2024. Todos los derechos reservados <a href=\'\' target=\'_blank\'>Ubunnie.</a>"}');
;// CONCATENATED MODULE: ./src/layouts/footer/footer-02/index.jsx




// Demo data

const Footer = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_clsx_default()("rn-footer-area footer-for-left-sticky-header", className),
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-lg-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "inner text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(logo/* default */.Z, {
                                logo: footer_02_namespaceObject.j
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "description mt--30",
                                dangerouslySetInnerHTML: {
                                    __html: footer_02_namespaceObject.M
                                }
                            })
                        ]
                    })
                })
            })
        })
    });
Footer.propTypes = {
    className: (external_prop_types_default()).string
};
/* harmony default export */ const footer_02 = (Footer);


/***/ }),

/***/ 5908:
/***/ ((module) => {

module.exports = [];

/***/ }),

/***/ 158:
/***/ ((module) => {

module.exports = JSON.parse('{"id":"header-data-2","logo":[{"src":"/logo.png"},{"src":"/logo-negro.png"}],"author":{"name":"Mark Jordan","image":{"src":"/images/client/testimonial-1.jpg"},"balance":"12ETH"}}');

/***/ }),

/***/ 6098:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"text":"Perfil","path":"list-item-1","icon":"feather-home"},{"id":2,"text":"Verificación","path":"list-item-2","icon":"feather-heart"},{"id":3,"text":"Planes","path":"list-item-3","icon":"feather-trending-up"},{"id":4,"text":"Galeria","path":"list-item-4","icon":"feather-trending-up"}]');

/***/ }),

/***/ 3492:
/***/ ((module) => {

module.exports = [];

/***/ }),

/***/ 2115:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"text":"Verificación","path":"list-item-1","icon":"feather-home"},{"id":1,"text":"Planes Historial","path":"list-item-2","icon":"feather-home"},{"id":3,"text":"Banear Usuario","path":"list-item-3","icon":"feather-trending-up"},{"id":3,"text":"Activar Plan Manual","path":"list-item-4","icon":"feather-trending-up"}]');

/***/ }),

/***/ 9934:
/***/ ((module) => {

module.exports = JSON.parse('{"title":"home-08","content":[{"section":"hero-section","banners":[{"id":1,"title":"Discover <br> Rare Digital art &amp; collect <span>NFT\'s</span>","path":"/connect","description":"The term fungible means something that can be replaced by something similar. So, by the name Non Fungible Tokens, we can easily understand.","authors":[{"name":"Mark Jordan","slug":"/author","image":{"src":"/images/client/client-2.png"}},{"name":"Farik Shaikh","slug":"/author","image":{"src":"/images/client/client-3.png"}},{"name":"John Doe","slug":"/author","image":{"src":"/images/client/client-5.png"}}],"bitCount":15,"auction_date":"2022-10-10","image":{"src":"/images/bg/bg-image-23.jpg"},"award_image":{"src":"/images/logo/award-logo.png"}},{"id":2,"title":"Discover <br> Rare Digital art &amp; collect <span>NFT\'s</span>","path":"/connect","description":"The term fungible means something that can be replaced by something similar. So, by the name Non Fungible Tokens, we can easily understand.","authors":[{"name":"Mark Jordan","slug":"/author","image":{"src":"/images/client/client-2.png"}},{"name":"Farik Shaikh","slug":"/author","image":{"src":"/images/client/client-3.png"}},{"name":"John Doe","slug":"/author","image":{"src":"/images/client/client-5.png"}}],"bitCount":15,"auction_date":"2022-10-10","image":{"src":"/images/bg/bg-image-22.jpg"},"award_image":{"src":"/images/logo/award-logo.png"}},{"id":3,"title":"Discover <br> Rare Digital art &amp; collect <span>NFT\'s</span>","path":"/connect","description":"The term fungible means something that can be replaced by something similar. So, by the name Non Fungible Tokens, we can easily understand.","authors":[{"name":"Mark Jordan","slug":"/author","image":{"src":"/images/client/client-2.png"}},{"name":"Farik Shaikh","slug":"/author","image":{"src":"/images/client/client-3.png"}},{"name":"John Doe","slug":"/author","image":{"src":"/images/client/client-5.png"}}],"bitCount":15,"auction_date":"2022-10-10","image":{"src":"/images/bg/bg-image-21.jpg"},"award_image":{"src":"/images/logo/award-logo.png"}}]},{"section":"top-sller-section","section_title":{"title":"Top Seller in"}},{"section":"live-explore-section","section_title":{"title":"Planes Activos"}},{"section":"collection-section","section_title":{"title":"Top Collection"}},{"section":"explore-product-section","section_title":{"title":"Explore Product"}},{"section":"service-section","section_title":{"title":"Make Easyer"},"items":[{"id":1,"title":"Set up your wallet","path":"/connect","subtitle":"Step-01","description":"Powerful features and inclusions, which makes Nuron standout, easily customizable and scalable.","images":[{"src":"/images/icons/shape-7.png"}]},{"id":2,"title":"Create your collection","path":"/collection","subtitle":"Step-02","description":"A great collection of beautiful website templates for your need. Choose the best suitable template.","images":[{"src":"/images/icons/shape-1.png"}]},{"id":3,"title":"Add your NFT\'s","path":"/connect","subtitle":"Step-03","description":"We\'ve made the template fully responsive, so it looks great on all devices: desktop, tablets and.","images":[{"src":"/images/icons/shape-5.png"}]},{"id":4,"title":"Sell Your NFT\'s","path":"/creator","subtitle":"Step-04","description":"I throw myself down among the tall grass by the stream as I lie close to the earth NFT\'s.","images":[{"src":"/images/icons/shape-6.png"}]}]}]}');

/***/ }),

/***/ 5678:
/***/ ((module) => {

module.exports = [];

/***/ })

};
;