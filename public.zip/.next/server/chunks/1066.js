"use strict";
exports.id = 1066;
exports.ids = [1066];
exports.modules = {

/***/ 4798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3715);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9306);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3__);




const VerificacionModal = ({ show , handleModal , data  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default()), {
        className: "rn-popup-modal ",
        show: show,
        onHide: handleModal,
        centered: true,
        children: [
            show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                type: "button",
                className: "btn-close",
                "aria-label": "Close",
                onClick: handleModal,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "feather-x"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default().Body), {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "placebid-form-box",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            className: "title",
                            children: "REGLAS DE VERIFICACI\xd3N"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bid-content",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "bid-content-top",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "small",
                                        children: 'Complete el proceso de verificaci\xf3n para aumentar sus visitas de perfil y llamadas telef\xf3nicas. Su foto de perfil recibir\xe1 un sello de "VERIFIED", asegurando a otros usuarios su autenticidad.'
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    children: "Pasos para la verificaci\xf3n:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: 'Enviar dos fotos: una de perfil y otra tipo selfie mostrando su rostro y sosteniendo un papel con el texto "UBUNNIE - 2024/09/14".'
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Adjuntar un video de m\xe1ximo 5 segundos de cuerpo completo, preferentemente girando, mencionando que es una persona real."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    children: "Rechazo de solicitudes:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Fotograf\xedas o videos con demasiados filtros o ediciones."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Contenido generado con inteligencia artificial."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "small",
                                    children: "En caso de rechazo, se notificar\xe1 y podr\xe1 presentar un documento de identidad o seguir las instrucciones enviadas a su n\xfamero de tel\xe9fono. Aseg\xfarese de que sus fotos y videos est\xe9n bien iluminados y visibles para evitar rechazo."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    children: "Tiempos y notificaciones:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Perm\xedtanos 24 horas para completar el proceso de verificaci\xf3n. Si no recibe su insignia, su solicitud fue rechazada."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "No solicitamos fotos ni videos por WhatsApp; las notificaciones ser\xe1n enviadas a trav\xe9s del sitio web oficial"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "No solicitamos fotos de c\xe9dula de identidad ni pasaporte, excepto si se necesita verificar su identidad tras un rechazo."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "small",
                                    children: "Nuestra prioridad es mantener la privacidad de sus datos personales."
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "bit-continue-button"
                        })
                    ]
                })
            })
        ]
    });
VerificacionModal.propTypes = {
    show: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool.isRequired),
    handleModal: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func.isRequired),
    data: prop_types__WEBPACK_IMPORTED_MODULE_2___default().shape({
        image: prop_types__WEBPACK_IMPORTED_MODULE_2___default().shape({}),
        title: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string)
    })
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VerificacionModal);


/***/ }),

/***/ 1066:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_product_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5665);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1449);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);
/* harmony import */ var _ui_anchor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4643);
/* harmony import */ var _components_modals_verificacion_modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4798);
/* harmony import */ var _utils_paqueteStore__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3655);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _utils_paqueteStore__WEBPACK_IMPORTED_MODULE_12__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _utils_paqueteStore__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 












const CreateNewAreaVerificacion = ({ className , space  })=>{
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_9__/* .useLocalStorage */ ._)("tokens");
    const [showProductModal, setShowProductModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [hasImageError, setHasImageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showBidModal, setShowBidModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [paisList, setPaisList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [verificacionesList, setVerificacionesList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedFile1, setSelectedFile1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [selectedFile2, setSelectedFile2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [selectedFile3, setSelectedFile3] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [selectedFile4, setSelectedFile4] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    console.log(token);
    const { register , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerDatosPerfil();
    }, []);
    const handleBidModal = ()=>{
        setShowBidModal((prev)=>!prev);
    };
    const handleSubmit = async (event)=>{
        event.preventDefault();
        if (!selectedFile1 && !selectedFile2 && !selectedFile3) {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Debe seleccionar 2 imagenes y un video");
            return;
        }
        (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Se comenzar\xe1 el envio de sus archivos");
        try {
            console.log(setSelectedFile1);
            const formData = new FormData();
            formData.append("foto1", selectedFile1);
            formData.append("foto2", selectedFile2);
            formData.append("video1", selectedFile3);
            formData.append("video2", selectedFile4);
            formData.append("token", token);
            const response = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addVerificacion", {
                method: "POST",
                body: formData
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            if (data.code == 200) {
                console.log(1);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(data.response);
                obtenerDatosPerfil();
            }
            if (data.code === 300) {
                console.log(data);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(data.response);
            }
        } catch (error) {
            console.error("Error uploading file:", error);
        }
    };
    const obtenerDatosPerfil = async ()=>{
        var requestOptionsPerfil = {
            method: "POST",
            body: JSON.stringify({
                token: localStorage.getItem("tokens")
            })
        };
        const data6 = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getVerificaciones", requestOptionsPerfil);
        const result6 = await data6.json();
        setVerificacionesList(result6.verificaciones);
        setIsLoad(true);
        console.log(verificacionesList);
    };
    const notify = ()=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Your product has submitted");
    const handleProductModal = ()=>{
        setShowProductModal(false);
    };
    // This function will be triggered when the file field change
    const imageChange = (e)=>{
        console.log(e);
        if (e.target.files && e.target.files.length > 0) {
            if (e.target.files[0].size > 10e6) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("El archivo no cumple con el peso maximo de 2mb");
            } else {
                setSelectedFile1(e.target.files[0]);
                console.log(selectedFile1);
            }
        }
    };
    const imageChange2 = (e)=>{
        console.log(e);
        if (e.target.files && e.target.files.length > 0) {
            if (e.target.files[0].size > 10e6) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("El archivo no cumple con el peso maximo de 2mb");
            } else {
                setSelectedFile2(e.target.files[0]);
            }
        }
    };
    const imageChange3 = (e)=>{
        console.log(e);
        if (e.target.files && e.target.files.length > 0) {
            if (e.target.files[0].size > 10e6) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("El archivo no cumple con el peso maximo de 10mb");
            } else {
                setSelectedFile3(e.target.files[0]);
            }
        }
    };
    const imageChange4 = (e)=>{
        console.log(e);
        if (e.target.files && e.target.files.length > 0) {
            if (e.target.files[0].size > 10e6) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("El archivo no cumple con el peso maximo de 10mb");
            } else {
                setSelectedFile4(e.target.files[0]);
            }
        }
    };
    const sortHandler = ({ value  })=>{
        setTipoUser(value);
        console.log(tipo_usuario);
    };
    const onSubmit = async (e)=>{
        console.log(e);
        console.log(selectedImage);
        var formData = new FormData();
        formData.append("file", selectedImage);
        formData.append("nombre", "texto");
        console.log(formData);
        var requestOptions = {
            method: "POST",
            body: formData,
            redirect: "follow"
        };
        fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/addVerificacion", requestOptions).then((response)=>{
            return response.json();
        }).then((json)=>{
            console.log(json);
            if (json.code == 200) {
                console.log(1);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
            if (json.code === 300) {
                console.log(json);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(json.response);
            }
        }).catch((error)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)("Ocurrio un error"));
    };
    if (isLoad) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("create-area", space === 1 && "mt-5", className),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            onSubmit: handleSubmit,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "container",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "row g-5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-lg-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-wrapper-one",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-8",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                            children: "Formulario de Verificaci\xf3n"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-4",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            className: "",
                                                            onClick: handleBidModal,
                                                            children: "Reglas de Verificac\xf3n"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-6",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "upload-area pb--20",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "upload-formate mb--30",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                            className: "title",
                                                                            children: "Primera Foto"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "formate",
                                                                            children: "Arrastre o elija su archivo para cargar"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "brows-file-wrapper",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            name: "file",
                                                                            accept: "image/*",
                                                                            id: "file",
                                                                            type: "file",
                                                                            className: "inputfile",
                                                                            "data-multiple-caption": "{count} files selected",
                                                                            multiple: false,
                                                                            onChange: imageChange
                                                                        }),
                                                                        selectedFile1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "createfileImage",
                                                                            src: URL.createObjectURL(selectedFile1),
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                            htmlFor: "file",
                                                                            title: "No File Choosen",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                    className: "feather-upload"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: "text-center",
                                                                                    children: "Selecciona tu Foto"
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                                    className: "text-center mt--10",
                                                                                    children: [
                                                                                        "PNG, GIF, WEBP, JPG.",
                                                                                        " ",
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                        " Max 10mb."
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                hasImageError && !selectedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                    children: "Image is required"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-6",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "upload-area pb--20",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "upload-formate mb--30",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                            className: "title",
                                                                            children: "Segunda Foto"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "formate",
                                                                            children: "Arrastre o elija su archivo para cargar"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "brows-file-wrapper",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            name: "file2",
                                                                            id: "file2",
                                                                            accept: "image/*",
                                                                            type: "file",
                                                                            className: "inputfile",
                                                                            "data-multiple-caption": "{count} files selected",
                                                                            multiple: true,
                                                                            onChange: imageChange2
                                                                        }),
                                                                        selectedFile2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "createfileImage",
                                                                            src: URL.createObjectURL(selectedFile2),
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                            htmlFor: "file2",
                                                                            title: "No File Choosen",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                    className: "feather-upload"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: "text-center",
                                                                                    children: "Escoge un archivo"
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                                    className: "text-center mt--10",
                                                                                    children: [
                                                                                        "PNG, GIF, WEBP, JPG.",
                                                                                        " ",
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                        " Max 10MB."
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                hasImageError && !selectedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                    children: "Image is required"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-6",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "upload-area pb--20",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "upload-formate mb--30",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                            className: "title",
                                                                            children: "Video"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "formate",
                                                                            children: "Arrastre o elija su archivo para cargar"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "brows-file-wrapper",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            type: "file",
                                                                            id: "file3",
                                                                            accept: "video/*",
                                                                            onChange: imageChange3
                                                                        }),
                                                                        selectedFile3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            id: "createfileImage",
                                                                            alt: "",
                                                                            "data-black-overlay": "6",
                                                                            children: " Se selecciono el video correctamente"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                            htmlFor: "file3",
                                                                            title: "No File Choosen",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                    className: "feather-upload"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: "text-center",
                                                                                    children: "Escoge un archivo"
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                                    className: "text-center mt--10",
                                                                                    children: [
                                                                                        "MP4, AVI, OTROS.",
                                                                                        " ",
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                        " Max 10Mb."
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                hasImageError && !selectedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                    children: "Image is required"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-6",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "upload-area pb--20",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "upload-formate mb--30",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                            className: "title",
                                                                            children: "Opcional"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "formate",
                                                                            children: "Arrastre o elija su archivo para cargar"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "brows-file-wrapper",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            name: "file4",
                                                                            id: "file4",
                                                                            accept: "video/mp4,video/x-m4v,video/*",
                                                                            type: "file",
                                                                            className: "inputfile",
                                                                            onChange: imageChange4
                                                                        }),
                                                                        selectedFile4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            id: "createfileImage",
                                                                            className: "color-primary",
                                                                            alt: "",
                                                                            "data-black-overlay": "6",
                                                                            children: " Se selecciono el video correctamente"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                            htmlFor: "file4",
                                                                            title: "No File Choosen",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                    className: "feather-upload"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: "text-center",
                                                                                    children: "Escoge un archivo"
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                                    className: "text-center mt--10",
                                                                                    children: [
                                                                                        "MP4, AVI, OTROS.",
                                                                                        " ",
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                        " Max 10Mb."
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                hasImageError && !selectedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_error_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                    children: "Image is required"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-12 col-xl-4",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "input-box",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                                color: "primary-alta",
                                                                fullwidth: true,
                                                                type: "submit",
                                                                "data-btn": "preview",
                                                                children: "Guardar"
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-12 mt-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "table-title-area d-flex",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        children: "Mis Solicitudes de Verificacion"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "box-table table-responsive",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                        className: "table upcoming-projects",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Codigo"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Foto"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Foto"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Video"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Video"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Status"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Mensaje"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                children: verificacionesList?.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        className: i % 2 === 0 ? "color-light" : "",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    children: item.cod
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    href: "https://ubunnie.com/backendUbunnie/" + item.foto_1,
                                                                    target: "_blank",
                                                                    children: " Link"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    href: "https://ubunnie.com/backendUbunnie/" + item.foto_2,
                                                                    target: "_blank",
                                                                    children: " Link"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    href: "https://ubunnie.com/backendUbunnie/" + item.video_1,
                                                                    target: "_blank",
                                                                    children: " Link"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    item.video_2 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        href: "https://ubunnie.com/backendUbunnie/" + item.video_2,
                                                                        target: "_blank",
                                                                        children: " Link"
                                                                    }),
                                                                    item.video_2 === "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: "No cargo un archivo"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    item.status == "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: "Enviada sin Procesar"
                                                                    }),
                                                                    item.status == "2" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: "Procesada con Exito!"
                                                                    }),
                                                                    item.status == "3" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: "Denegada"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    children: item.mensaje
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {})
                                                            })
                                                        ]
                                                    }, item.cod))
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_verificacion_modal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    show: showBidModal,
                    handleModal: handleBidModal
                })
            ]
        });
    }
    ;
};
CreateNewAreaVerificacion.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
    space: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        1
    ])
};
CreateNewAreaVerificacion.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateNewAreaVerificacion);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;