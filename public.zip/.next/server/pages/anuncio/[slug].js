"use strict";
(() => {
var exports = {};
exports.id = 2037;
exports.ids = [2037];
exports.modules = {

/***/ 910:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9306);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3715);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _ui_error_text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1449);
/* harmony import */ var src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2512);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const VerImagenModal = ({ show , handleModal , data  })=>{
    console.log(data);
    const [token, setToken] = (0,src_hooks_use_local_storage__WEBPACK_IMPORTED_MODULE_6__/* .useLocalStorage */ ._)("tokens");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    console.log(typeof data) // number
    ;
    if (typeof data != "object") {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default()), {
            className: "rn-popup-modal report-modal-wrapper",
            show: show,
            onHide: handleModal,
            centered: true,
            children: [
                show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "button",
                    className: "btn-close",
                    "aria-label": "Close",
                    onClick: handleModal,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: "feather-x"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Body), {
                    children: data && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            (data.includes(".jpg") || data.includes(".png") || data.includes(".jpeg")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    width: 400,
                                    height: 500,
                                    id: "multimedia_1",
                                    src: data,
                                    alt: "",
                                    "data-black-overlay": "6"
                                })
                            }),
                            (data.includes(".mp4") || data.includes(".avi") || data.includes(".WMV")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                    id: "multimedia_1",
                                    controls: true,
                                    muted: true,
                                    "data-black-overlay": "6",
                                    width: 400,
                                    height: 500,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                        type: "video/mp4",
                                        src: data
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        });
    }
};
VerImagenModal.propTypes = {
    show: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool.isRequired),
    handleModal: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().func.isRequired)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VerImagenModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7188:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: external "react-bootstrap/TabContainer"
var TabContainer_ = __webpack_require__(6348);
var TabContainer_default = /*#__PURE__*/__webpack_require__.n(TabContainer_);
// EXTERNAL MODULE: external "react-bootstrap/TabContent"
var TabContent_ = __webpack_require__(1130);
var TabContent_default = /*#__PURE__*/__webpack_require__.n(TabContent_);
// EXTERNAL MODULE: external "react-bootstrap/TabPane"
var TabPane_ = __webpack_require__(9722);
var TabPane_default = /*#__PURE__*/__webpack_require__.n(TabPane_);
// EXTERNAL MODULE: external "react-bootstrap/Nav"
var Nav_ = __webpack_require__(2540);
var Nav_default = /*#__PURE__*/__webpack_require__.n(Nav_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/components/ui/anchor/index.jsx
var ui_anchor = __webpack_require__(4643);
;// CONCATENATED MODULE: ./src/components/top-seller/layout-02/index.jsx





const TopSeller = ({ name , time , path , image , eth , isVarified  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "top-seller-inner-one",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "top-seller-wrapper",
            children: [
                image?.src && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: external_clsx_default()("thumbnail", isVarified && "varified"),
                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                        path: path,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: image.src,
                            alt: image?.alt || "Nft_Profile",
                            width: image?.width || 50,
                            height: image?.height || 50
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "top-seller-content",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            children: [
                                eth && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        eth,
                                        " by"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_anchor/* default */.Z, {
                                    path: path,
                                    children: name
                                })
                            ]
                        }),
                        time && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "count-number",
                            children: time
                        })
                    ]
                })
            ]
        })
    });
TopSeller.propTypes = {
    name: (external_prop_types_default()).string.isRequired,
    time: (external_prop_types_default()).string,
    path: (external_prop_types_default()).string.isRequired,
    eth: (external_prop_types_default()).string,
    image: external_prop_types_default().shape({
        src: external_prop_types_default().oneOfType([
            external_prop_types_default().shape(),
            (external_prop_types_default()).string
        ]).isRequired,
        alt: (external_prop_types_default()).string,
        width: (external_prop_types_default()).number,
        height: (external_prop_types_default()).number
    }).isRequired,
    isVarified: (external_prop_types_default()).bool
};
/* harmony default export */ const layout_02 = (TopSeller);

// EXTERNAL MODULE: ./src/utils/types.js
var types = __webpack_require__(8663);
;// CONCATENATED MODULE: ./src/components/product-details/bid-tab/bids-tab-content.jsx




const BidsTabContent = ({ bids  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: bids?.map((bid)=>/*#__PURE__*/ jsx_runtime_.jsx(layout_02, {
                name: bid.user.name,
                eth: bid.amount,
                path: bid.user.slug,
                time: bid.bidAt,
                image: {
                    src: bid.user.image.src,
                    width: 44,
                    height: 44
                }
            }, bid.id))
    });
BidsTabContent.propTypes = {
    bids: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        id: types/* IDType.isRequired */.iJ.isRequired,
        user: external_prop_types_default().shape({
            name: (external_prop_types_default()).string.isRequired,
            slug: (external_prop_types_default()).string.isRequired,
            image: types/* ImageType.isRequired */.__.isRequired
        }),
        amount: (external_prop_types_default()).string.isRequired,
        bidAt: (external_prop_types_default()).string.isRequired
    }))
};
/* harmony default export */ const bids_tab_content = (BidsTabContent);

// EXTERNAL MODULE: ./src/components/top-seller/layout-01/index.jsx
var layout_01 = __webpack_require__(491);
;// CONCATENATED MODULE: ./src/components/product-details/bid-tab/details-tab-content.jsx




const DetailsTabContent = ({ owner , properties , tags  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rn-pd-bd-wrapper mt--20",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(layout_01/* default */.Z, {
                name: owner.name,
                total_sale: owner.total_sale,
                slug: owner.slug,
                image: owner.image
            }),
            properties && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "rn-pd-sm-property-wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        className: "pd-property-title",
                        children: "Property"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "property-wrapper",
                        children: properties.map((property)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "pd-property-inner",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "color-body type",
                                        children: property.type
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "color-white value",
                                        children: property.value
                                    })
                                ]
                            }, property.id))
                    })
                ]
            }),
            tags && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "rn-pd-sm-property-wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        className: "pd-property-title",
                        children: "Tags"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "catagory-wrapper",
                        children: tags.map((tag)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "pd-property-inner",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "color-body type",
                                        children: tag.type
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "color-white value",
                                        children: tag.value
                                    })
                                ]
                            }, tag.id))
                    })
                ]
            })
        ]
    });
DetailsTabContent.propTypes = {
    owner: external_prop_types_default().shape({
        name: (external_prop_types_default()).string,
        total_sale: (external_prop_types_default()).number,
        slug: (external_prop_types_default()).string,
        image: types/* ImageType */.__
    }),
    properties: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        id: types/* IDType */.iJ,
        type: (external_prop_types_default()).string,
        value: (external_prop_types_default()).string
    })),
    tags: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        id: types/* IDType */.iJ,
        type: (external_prop_types_default()).string,
        value: (external_prop_types_default()).string
    }))
};
/* harmony default export */ const details_tab_content = (DetailsTabContent);

;// CONCATENATED MODULE: ./src/components/product-details/bid-tab/history-tab-content.jsx




const HistoryTabContent = ({ history  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: history?.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(layout_02, {
                name: item.user.name,
                eth: item.amount,
                path: item.user.slug,
                time: item.bidAt,
                image: item.user.image
            }, item.id))
    });
HistoryTabContent.propTypes = {
    history: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        id: types/* IDType.isRequired */.iJ.isRequired,
        user: external_prop_types_default().shape({
            name: (external_prop_types_default()).string.isRequired,
            slug: (external_prop_types_default()).string.isRequired,
            image: types/* ImageType.isRequired */.__.isRequired
        }),
        amount: (external_prop_types_default()).string.isRequired,
        bidAt: (external_prop_types_default()).string.isRequired
    }))
};
/* harmony default export */ const history_tab_content = (HistoryTabContent);

;// CONCATENATED MODULE: ./src/components/product-details/bid-tab/index.jsx










const BidTab = ({ className , bids , owner , properties , tags , history  })=>/*#__PURE__*/ jsx_runtime_.jsx((TabContainer_default()), {
        defaultActiveKey: "nav-home",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: external_clsx_default()("tab-wrapper-one", className),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                    className: "tab-button-one",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()), {
                        as: "div",
                        className: "nav-tabs",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                as: "button",
                                eventKey: "nav-home",
                                children: "Bids"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                as: "button",
                                eventKey: "nav-profile",
                                children: "Details"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                as: "button",
                                eventKey: "nav-contact",
                                children: "History"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TabContent_default()), {
                    className: "rn-bid-content",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TabPane_default()), {
                            eventKey: "nav-home",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(bids_tab_content, {
                                bids: bids
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TabPane_default()), {
                            eventKey: "nav-profile",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(details_tab_content, {
                                owner: owner,
                                properties: properties,
                                tags: tags
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TabPane_default()), {
                            eventKey: "nav-contact",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(history_tab_content, {
                                history: history
                            })
                        })
                    ]
                })
            ]
        })
    });
BidTab.propTypes = {
    className: (external_prop_types_default()).string,
    bids: external_prop_types_default().arrayOf(external_prop_types_default().shape({})),
    owner: external_prop_types_default().shape({}),
    properties: external_prop_types_default().arrayOf(external_prop_types_default().shape({})),
    tags: external_prop_types_default().arrayOf(external_prop_types_default().shape({})),
    history: external_prop_types_default().arrayOf(external_prop_types_default().shape({}))
};
/* harmony default export */ const bid_tab = ((/* unused pure expression or super */ null && (BidTab)));


/***/ }),

/***/ 1869:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(491);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8663);





const ProductCategory = ({ className , owner  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("catagory", className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    "Catagory ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "color-body",
                        children: "10% royalties"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                name: owner.name,
                slug: owner.slug,
                image: {
                    src: owner.image.src,
                    width: 44,
                    height: 44
                }
            })
        ]
    });
ProductCategory.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    owner: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        name: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        slug: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        image: _utils_types__WEBPACK_IMPORTED_MODULE_4__/* .ImageType */ .__
    })
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ProductCategory)));


/***/ }),

/***/ 8692:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(491);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8663);





const ProductCollection = ({ className , collection  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("collection", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: "Collections"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_top_seller_layout_01__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                name: collection.name,
                slug: collection.slug,
                image: {
                    src: collection.image.src,
                    width: 44,
                    height: 44
                }
            })
        ]
    });
ProductCollection.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    collection: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        name: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        slug: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        image: _utils_types__WEBPACK_IMPORTED_MODULE_4__/* .ImageType */ .__
    })
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ProductCollection)));


/***/ }),

/***/ 4439:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap_TabContent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1130);
/* harmony import */ var react_bootstrap_TabContent__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_TabContent__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_bootstrap_TabContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6348);
/* harmony import */ var react_bootstrap_TabContainer__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_TabContainer__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_bootstrap_TabPane__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9722);
/* harmony import */ var react_bootstrap_TabPane__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_TabPane__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2540);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8663);








const GalleryTab = ({ images  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "product-tab-wrapper",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_TabContainer__WEBPACK_IMPORTED_MODULE_4___default()), {
            defaultActiveKey: "nav-0",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pd-tab-inner",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_6___default()), {
                        className: "rn-pd-nav rn-pd-rt-content nav-pills",
                        children: images?.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_6___default().Link), {
                                as: "button",
                                eventKey: `nav-${index}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "rn-pd-sm-thumbnail",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: image.src,
                                        alt: image?.alt || "Product",
                                        width: 167,
                                        height: 167
                                    })
                                })
                            }, image.src))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_TabContent__WEBPACK_IMPORTED_MODULE_3___default()), {
                        className: "rn-pd-content",
                        children: images?.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_TabPane__WEBPACK_IMPORTED_MODULE_5___default()), {
                                eventKey: `nav-${index}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "rn-pd-thumbnail",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: image.src,
                                        alt: image?.alt || "Product",
                                        width: 560,
                                        height: 560,
                                        priority: true
                                    })
                                })
                            }, image.src))
                    })
                ]
            })
        })
    });
GalleryTab.propTypes = {
    images: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_7__/* .ImageType */ .__)
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (GalleryTab)));


/***/ }),

/***/ 2313:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ui_anchor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4643);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3715);
/* harmony import */ var _components_modals_placebid_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3709);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8663);










const Countdown = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(()=>__webpack_require__.e(/* import() */ 908).then(__webpack_require__.bind(__webpack_require__, 908)), {
    loadableGenerated: {
        modules: [
            "..\\components\\product-details\\place-bet.jsx -> " + "@ui/countdown/layout-02"
        ]
    },
    ssr: false
});
const PlaceBet = ({ highest_bid , auction_date , btnColor , className  })=>{
    const [showBidModal, setShowBidModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleBidModal = ()=>{
        setShowBidModal((prev)=>!prev);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("place-bet-area", className),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "rn-bet-create",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bid-list winning-bid",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "title",
                                        children: "Winning bit"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "top-seller-inner-one",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "top-seller-wrapper",
                                            children: [
                                                highest_bid.bidder?.image?.src && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "thumbnail",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_anchor__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        path: highest_bid.bidder.slug,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            src: highest_bid.bidder.image.src,
                                                            alt: "Nft_Profile",
                                                            width: 44,
                                                            height: 44
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "top-seller-content",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "heighest-bid",
                                                            children: [
                                                                "Heighest bid",
                                                                " ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_anchor__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                                    path: highest_bid.bidder.slug,
                                                                    children: highest_bid.bidder.name
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "count-number",
                                                            children: highest_bid.amount
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            auction_date && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bid-list left-bid",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "title",
                                        children: "Auction has ended"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Countdown, {
                                        className: "mt--15",
                                        date: auction_date
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        color: btnColor || "primary-alta",
                        className: "mt--30",
                        onClick: handleBidModal,
                        children: "Place a Bid"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_placebid_modal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                show: showBidModal,
                handleModal: handleBidModal
            })
        ]
    });
};
PlaceBet.propTypes = {
    highest_bid: prop_types__WEBPACK_IMPORTED_MODULE_4___default().shape({
        amount: (prop_types__WEBPACK_IMPORTED_MODULE_4___default().string),
        bidder: prop_types__WEBPACK_IMPORTED_MODULE_4___default().shape({
            name: (prop_types__WEBPACK_IMPORTED_MODULE_4___default().string),
            image: _utils_types__WEBPACK_IMPORTED_MODULE_9__/* .ImageType */ .__,
            slug: (prop_types__WEBPACK_IMPORTED_MODULE_4___default().string)
        })
    }),
    auction_date: (prop_types__WEBPACK_IMPORTED_MODULE_4___default().string),
    btnColor: (prop_types__WEBPACK_IMPORTED_MODULE_4___default().string),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_4___default().string)
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (PlaceBet)));


/***/ }),

/***/ 7329:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _share_dropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3823);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1301);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_icons_fa__WEBPACK_IMPORTED_MODULE_4__]);
react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ProductTitleNuevo = ({ className , title , usuario  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("pd-title-area", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                className: "title",
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "pd-react-area",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "heart-count",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaShare, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "Compartir"
                        })
                    ]
                })
            })
        ]
    });
ProductTitleNuevo.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
    likeCount: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().number)
};
ProductTitleNuevo.defaultProps = {
    likeCount: 0
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductTitleNuevo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7733:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _share_dropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3823);




const ProductTitle = ({ className , title , likeCount  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("pd-title-area", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                className: "title",
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pd-react-area",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "heart-count",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "feather-heart"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: likeCount
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "count",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_share_dropdown__WEBPACK_IMPORTED_MODULE_3__["default"], {})
                    })
                ]
            })
        ]
    });
ProductTitle.propTypes = {
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
    likeCount: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().number)
};
ProductTitle.defaultProps = {
    likeCount: 0
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ProductTitle)));


/***/ }),

/***/ 4929:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);



const Sticky = ({ children , className , top  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("widge-wrapper", className),
        style: {
            top
        },
        children: children
    });
Sticky.propTypes = {
    children: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().node.isRequired),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    top: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
};
Sticky.defaultProps = {
    top: "100px"
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Sticky)));


/***/ }),

/***/ 3002:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_sticky__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4929);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3715);
/* harmony import */ var _components_product_details_gallery_tab__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4439);
/* harmony import */ var _components_product_details_title__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7733);
/* harmony import */ var _components_product_details_category__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1869);
/* harmony import */ var _components_product_details_collection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8692);
/* harmony import */ var _components_product_details_bid_tab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7188);
/* harmony import */ var _components_product_details_place_bet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2313);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8663);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6905);
/* harmony import */ var _components_modals_galeria___WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(910);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_product_details_title_new__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7329);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7333);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1301);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7425);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_icons_md__WEBPACK_IMPORTED_MODULE_13__, _components_modals_galeria___WEBPACK_IMPORTED_MODULE_14__, _components_product_details_title_new__WEBPACK_IMPORTED_MODULE_16__, react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__, react_icons_fa__WEBPACK_IMPORTED_MODULE_18__, react_icons_ai__WEBPACK_IMPORTED_MODULE_19__]);
([react_icons_md__WEBPACK_IMPORTED_MODULE_13__, _components_modals_galeria___WEBPACK_IMPORTED_MODULE_14__, _components_product_details_title_new__WEBPACK_IMPORTED_MODULE_16__, react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__, react_icons_fa__WEBPACK_IMPORTED_MODULE_18__, react_icons_ai__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















// Demo Image
const ProductDetailsArea = ({ space , className , product , servicios , tarifas  })=>{
    console.log(product);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(product);
    const [serviciosList, setDataServicios] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(servicios);
    const [tarifasList, setDataTarifas] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(tarifas);
    const [direccion, setDireccion] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)("https://bo.ubunnies.com/backendUbunnie/");
    console.log(direccion);
    const [isLoad, setIsLoad] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(false);
    const [archivoSelect, setArchivoSelect] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)("");
    const [showBidModal, setShowBidModal] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        setIsLoad(true);
    }, []);
    const handleBidModal = (te)=>{
        console.log(te);
        setArchivoSelect(te);
        setShowBidModal((prev)=>!prev);
    };
    console.log(data);
    if (data) {
        if (data.activo == "2") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("product-details-area", space === 1 && "rn-section-gapTop", className),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "row g-5"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                            children: " Este usuario por no cumplir con nuestos t\xe9rminos y politicas ha sido baneado de nuestra aplicaci\xf3n. "
                        })
                    ]
                })
            });
        } else {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("product-details-area", space === 1 && "rn-section-gapTop", className),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "container",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row g-5",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                            children: [
                                                data.nombre,
                                                data.paquete_activo == "4" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                        src: "/images/iconos/start.png",
                                                        width: 100,
                                                        height: 100
                                                    })
                                                }),
                                                data.paquete_activo == "3" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                        src: "/images/iconos/VIP.png",
                                                        width: 100,
                                                        height: 100
                                                    })
                                                }),
                                                data.paquete_activo == "2" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                        src: "/images/iconos/verified.png",
                                                        width: 100,
                                                        height: 100
                                                    })
                                                })
                                            ]
                                        }),
                                        data.paquete_activo == "1" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                data.fotografia_portada != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        id: "createfileImagePortada",
                                                                        src: direccion + data.fotografia_portada,
                                                                        alt: "",
                                                                        "data-black-overlay": "6"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "createfileImagePortada",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.fotografia_portada)
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                }),
                                                data.multimedia_1 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-3",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "upload-area-galeria pb--20",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "brows-file-wrapper2",
                                                                children: data.multimedia_1 != "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        (data.multimedia_1.includes(".jpg") || data.multimedia_1.includes(".png") || data.multimedia_1.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    id: "multimedia_1",
                                                                                    src: direccion + data.multimedia_1,
                                                                                    alt: "",
                                                                                    "data-black-overlay": "6"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "Ver",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        }),
                                                                        (data.multimedia_1.includes(".mp4") || data.multimedia_1.includes(".avi") || data.multimedia_1.includes(".WMV")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                                    id: "multimedia_1",
                                                                                    controls: true,
                                                                                    muted: true,
                                                                                    "data-black-overlay": "6",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                        type: "video/mp4",
                                                                                        src: direccion + data.multimedia_1
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "No File Choosen",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        data.paquete_activo == "2" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                data.fotografia_portada != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        id: "createfileImagePortada",
                                                                        src: direccion + data.fotografia_portada,
                                                                        alt: "",
                                                                        "data-black-overlay": "6"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "createfileImagePortada",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.fotografia_portada)
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                }),
                                                data.multimedia_1 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-3",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "upload-area-galeria pb--20",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "brows-file-wrapper2",
                                                                children: data.multimedia_1 != "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        (data.multimedia_1.includes(".jpg") || data.multimedia_1.includes(".png") || data.multimedia_1.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    id: "multimedia_1",
                                                                                    src: direccion + data.multimedia_1,
                                                                                    alt: "",
                                                                                    "data-black-overlay": "6"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "Ver",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        }),
                                                                        (data.multimedia_1.includes(".mp4") || data.multimedia_1.includes(".avi") || data.multimedia_1.includes(".WMV")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                                    id: "multimedia_1",
                                                                                    controls: true,
                                                                                    muted: true,
                                                                                    "data-black-overlay": "6",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                        type: "video/mp4",
                                                                                        src: direccion + data.multimedia_1
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "No File Choosen",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    })
                                                }),
                                                data.multimedia_2 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_2.includes(".jpg") || data.multimedia_2.includes(".png") || data.multimedia_1.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_2",
                                                                            src: direccion + data.multimedia_2,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_2",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_2)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_2.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_2",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_2
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_2",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_2)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_3 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "brows-file-wrapper2",
                                                        children: [
                                                            (data.multimedia_3.includes(".jpg") || data.multimedia_3.includes(".png") || data.multimedia_3.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        id: "multimedia_3",
                                                                        src: direccion + data.multimedia_3,
                                                                        alt: "",
                                                                        "data-black-overlay": "6"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "multimedia_3",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.multimedia_3)
                                                                    })
                                                                ]
                                                            }),
                                                            data.multimedia_3.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                        id: "multimedia_3",
                                                                        controls: true,
                                                                        muted: true,
                                                                        "data-black-overlay": "6",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                            type: "video/mp4",
                                                                            src: direccion + data.multimedia_3
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "multimedia_3",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.multimedia_3)
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                data.multimedia_4 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_4.includes(".jpg") || data.multimedia_4.includes(".png") || data.multimedia_4.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_4",
                                                                            src: direccion + data.multimedia_4,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_4",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_4)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_4.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_4",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_4
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_4",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_4)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        data.paquete_activo == "3" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                data.fotografia_portada != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        id: "createfileImagePortada",
                                                                        src: direccion + data.fotografia_portada,
                                                                        alt: "",
                                                                        "data-black-overlay": "6"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "createfileImagePortada",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.fotografia_portada)
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                }),
                                                data.multimedia_1 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-3",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "upload-area-galeria pb--20",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "brows-file-wrapper2",
                                                                children: data.multimedia_1 != "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        (data.multimedia_1.includes(".jpg") || data.multimedia_1.includes(".png") || data.multimedia_1.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    id: "multimedia_1",
                                                                                    src: direccion + data.multimedia_1,
                                                                                    alt: "",
                                                                                    "data-black-overlay": "6"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "Ver",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        }),
                                                                        (data.multimedia_1.includes(".mp4") || data.multimedia_1.includes(".avi") || data.multimedia_1.includes(".WMV")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                                    id: "multimedia_1",
                                                                                    controls: true,
                                                                                    muted: true,
                                                                                    "data-black-overlay": "6",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                        type: "video/mp4",
                                                                                        src: direccion + data.multimedia_1
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "No File Choosen",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    })
                                                }),
                                                data.multimedia_2 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_2.includes(".jpg") || data.multimedia_2.includes(".png") || data.multimedia_1.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_2",
                                                                            src: direccion + data.multimedia_2,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_2",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_2)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_2.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_2",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_2
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_2",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_2)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_3 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "brows-file-wrapper2",
                                                        children: [
                                                            (data.multimedia_3.includes(".jpg") || data.multimedia_3.includes(".png") || data.multimedia_3.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        id: "multimedia_3",
                                                                        src: direccion + data.multimedia_3,
                                                                        alt: "",
                                                                        "data-black-overlay": "6"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "multimedia_3",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.multimedia_3)
                                                                    })
                                                                ]
                                                            }),
                                                            data.multimedia_3.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                        id: "multimedia_3",
                                                                        controls: true,
                                                                        muted: true,
                                                                        "data-black-overlay": "6",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                            type: "video/mp4",
                                                                            src: direccion + data.multimedia_3
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "multimedia_3",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.multimedia_3)
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                data.multimedia_4 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_4.includes(".jpg") || data.multimedia_4.includes(".png") || data.multimedia_4.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_4",
                                                                            src: direccion + data.multimedia_4,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_4",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_4)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_4.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_4",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_4
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_4",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_4)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_5 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_5.includes(".jpg") || data.multimedia_5.includes(".png") || data.multimedia_5.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_5",
                                                                            src: direccion + data.multimedia_5,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_5",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_5)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_5.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_5",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_5
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_5",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_5)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_6 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_6.includes(".jpg") || data.multimedia_6.includes(".png") || data.multimedia_6.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_6",
                                                                            src: direccion + data.multimedia_6,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_6",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_6)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_6.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_6",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_6
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_6",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_6)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_7 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_7.includes(".jpg") || data.multimedia_7.includes(".png") || data.multimedia_7.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_7",
                                                                            src: direccion + data.multimedia_7,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_7",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_7)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_7.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_7",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_7
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_7",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_7)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_8 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_8.includes(".jpg") || data.multimedia_8.includes(".png") || data.multimedia_8.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_8",
                                                                            src: direccion + data.multimedia_8,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_8",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_8)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_8.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_8",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_8
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_8",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_8)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        data.paquete_activo == "4" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                data.fotografia_portada != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        id: "createfileImagePortada",
                                                                        src: direccion + data.fotografia_portada,
                                                                        alt: "",
                                                                        "data-black-overlay": "6"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "createfileImagePortada",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.fotografia_portada)
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                }),
                                                data.multimedia_1 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-3",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "upload-area-galeria pb--20",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "brows-file-wrapper2",
                                                                children: data.multimedia_1 != "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        (data.multimedia_1.includes(".jpg") || data.multimedia_1.includes(".png") || data.multimedia_1.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    id: "multimedia_1",
                                                                                    src: direccion + data.multimedia_1,
                                                                                    alt: "",
                                                                                    "data-black-overlay": "6"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "Ver",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        }),
                                                                        (data.multimedia_1.includes(".mp4") || data.multimedia_1.includes(".avi") || data.multimedia_1.includes(".WMV")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                                    id: "multimedia_1",
                                                                                    controls: true,
                                                                                    muted: true,
                                                                                    "data-black-overlay": "6",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                        type: "video/mp4",
                                                                                        src: direccion + data.multimedia_1
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                    htmlFor: "multimedia_1",
                                                                                    title: "No File Choosen",
                                                                                    onClick: ()=>handleBidModal(direccion + data.multimedia_1)
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    })
                                                }),
                                                data.multimedia_2 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_2.includes(".jpg") || data.multimedia_2.includes(".png") || data.multimedia_1.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_2",
                                                                            src: direccion + data.multimedia_2,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_2",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_2)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_2.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_2",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_2
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_2",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_2)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_3 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "brows-file-wrapper2",
                                                        children: [
                                                            (data.multimedia_3.includes(".jpg") || data.multimedia_3.includes(".png") || data.multimedia_3.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        id: "multimedia_3",
                                                                        src: direccion + data.multimedia_3,
                                                                        alt: "",
                                                                        "data-black-overlay": "6"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "multimedia_3",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.multimedia_3)
                                                                    })
                                                                ]
                                                            }),
                                                            data.multimedia_3.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                        id: "multimedia_3",
                                                                        controls: true,
                                                                        muted: true,
                                                                        "data-black-overlay": "6",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                            type: "video/mp4",
                                                                            src: direccion + data.multimedia_3
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "multimedia_3",
                                                                        title: "No File Choosen",
                                                                        onClick: ()=>handleBidModal(direccion + data.multimedia_3)
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                data.multimedia_4 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_4.includes(".jpg") || data.multimedia_4.includes(".png") || data.multimedia_4.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_4",
                                                                            src: direccion + data.multimedia_4,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_4",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_4)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_4.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_4",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_4
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_4",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_4)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_5 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_5.includes(".jpg") || data.multimedia_5.includes(".png") || data.multimedia_5.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_5",
                                                                            src: direccion + data.multimedia_5,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_5",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_5)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_5.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_5",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_5
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_5",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_5)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_6 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_6.includes(".jpg") || data.multimedia_6.includes(".png") || data.multimedia_6.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_6",
                                                                            src: direccion + data.multimedia_6,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_6",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_6)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_6.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_6",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_6
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_6",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_6)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_7 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_7.includes(".jpg") || data.multimedia_7.includes(".png") || data.multimedia_7.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_7",
                                                                            src: direccion + data.multimedia_7,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_7",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_7)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_7.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_7",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_7
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_7",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_7)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_8 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_8.includes(".jpg") || data.multimedia_8.includes(".png") || data.multimedia_8.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_8",
                                                                            src: direccion + data.multimedia_8,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_8",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_8)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_8.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_8",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_8
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_8",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_8)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_9 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_9.includes(".jpg") || data.multimedia_9.includes(".png") || data.multimedia_9.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_9",
                                                                            src: direccion + data.multimedia_9,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_9",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_9)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_9.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_9",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_9
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_9",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_9)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_10 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_10.includes(".jpg") || data.multimedia_10.includes(".png") || data.multimedia_10.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_10",
                                                                            src: direccion + data.multimedia_10,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_10",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_10)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_10.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_10",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_10
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_10",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_10)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                data.multimedia_11 != "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "upload-area-galeria pb--20",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "brows-file-wrapper2",
                                                            children: [
                                                                (data.multimedia_11.includes(".jpg") || data.multimedia_11.includes(".png") || data.multimedia_11.includes(".jpeg")) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            id: "multimedia_11",
                                                                            src: direccion + data.multimedia_11,
                                                                            alt: "",
                                                                            "data-black-overlay": "6"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_11",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_11)
                                                                        })
                                                                    ]
                                                                }),
                                                                data.multimedia_11.includes(".mp4") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                                                            id: "multimedia_11",
                                                                            controls: true,
                                                                            muted: true,
                                                                            "data-black-overlay": "6",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                                type: "video/mp4",
                                                                                src: direccion + data.multimedia_11
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "multimedia_11",
                                                                            title: "No File Choosen",
                                                                            onClick: ()=>handleBidModal(direccion + data.multimedia_11)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-2 col-md-2 col-sm-6 mt_md--50 mt_sm--60"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-8 col-md-8 mt_md--50 mt_sm--60"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-2 col-md-2 mt_md--50 mt_sm--60"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-12 col-md-12 col-sm-12 mt_md--50 mt_sm--60",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "rn-pd-content-area",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_details_title_new__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                title: data.ciudad_1,
                                                usuario: data.usuario
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "bid",
                                                children: [
                                                    "ID: ",
                                                    data.cod,
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "price"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "title-name mt--10",
                                                children: "Sobre mi"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                dangerouslySetInnerHTML: {
                                                    __html: data.sobre_mi
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                className: "inline",
                                                children: [
                                                    data.llamada != "0" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                        href: "tel:" + data.fone + data.telefono,
                                                        target: "__blank",
                                                        children: [
                                                            "  ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__.FaPhone, {
                                                                className: "fs-1"
                                                            }),
                                                            " "
                                                        ]
                                                    }),
                                                    "+",
                                                    data.fone,
                                                    " ",
                                                    data.telefono,
                                                    data.whatsapp != "0" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                        href: "https://api.whatsapp.com/send?phone=" + data.fone + data.telefono + "&text=Hola%20,quiero%20ponerme%20en%20contacto%20con%20usted,%20por%20sus%20servicios.",
                                                        target: "__blank",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_18__.FaWhatsapp, {
                                                                className: "fs-1"
                                                            }),
                                                            " "
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Nacionalidad:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "",
                                                                children: data.gentilicio
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Edad:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "",
                                                                children: data.edad
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Ojos:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "",
                                                                children: data.color
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Contextura:"
                                                            }),
                                                            data.contextura == "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "",
                                                                children: "Delgada"
                                                            }),
                                                            data.contextura == "2" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "",
                                                                children: "Media"
                                                            }),
                                                            data.contextura == "3" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "",
                                                                children: "Gruesa"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Altura:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: data.talla
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Etnia:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: data.etnia
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Cabello:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: data.color_pelo
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Bebe:"
                                                            }),
                                                            data.bebe == "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: "No"
                                                            }),
                                                            data.bebe == "2" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: "Si"
                                                            }),
                                                            data.bebe == "3" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: "Eventualmente"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Peso:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: data.peso
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Fuma:"
                                                            }),
                                                            data.fuma == "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: "No"
                                                            }),
                                                            data.fuma == "2" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: "Si"
                                                            }),
                                                            data.fuma == "3" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "-mt--10",
                                                                children: "Eventualmente"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Tattos & Piercing"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    data.tatto == "1" && "Si",
                                                                    data.tatto == "2" && "No",
                                                                    "/",
                                                                    data.fuma == "1" && "Si",
                                                                    data.fuma == "2" && "No"
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    data.miembro == "1" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Posee Miembro:"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    data.miembro == "1" && "Si",
                                                                    data.miembro == "2" && "No"
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    data.miembro_tamano != "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mt_md--10 mt_sm--60 mb--10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                className: "color-primary",
                                                                children: "Tama\xf1o Miembro:"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: data.miembro_tamano
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-6 col-sm-12 mt--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "table-title-area d-flex",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                    className: "color-primary",
                                                                    children: "Mis Servicios"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "box-table table-responsive",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                                    className: "table upcoming-projects",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: "Servicio"
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: "Incluido"
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: "Precio"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                            children: serviciosList?.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                    className: i % 2 === 0 ? "color-light" : "",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                children: item.servicio
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                children: [
                                                                                                    item.incluido == "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                                                            children: [
                                                                                                                " ",
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_18__.FaCheck, {
                                                                                                                    className: "color-primary"
                                                                                                                })
                                                                                                            ]
                                                                                                        })
                                                                                                    }),
                                                                                                    item.incluido != "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                                                            children: [
                                                                                                                " ",
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_19__.AiOutlineClose, {
                                                                                                                    className: "color-danger"
                                                                                                                })
                                                                                                            ]
                                                                                                        })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                children: [
                                                                                                    item.precio == 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                                                                                    item.precio != "0" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                        children: [
                                                                                                            item.precio,
                                                                                                            " bs"
                                                                                                        ]
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                }, item.cod))
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-6 col-sm-12 mt--20",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "table-title-area d-flex",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                    className: "color-primary",
                                                                    children: "Mis Tarifas"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "box-table table-responsive",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                                    className: "table upcoming-projects",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: "Tarifa"
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: "Visita"
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            children: "Salida"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                            children: tarifasList?.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                    className: i % 2 === 0 ? "color-light" : "",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                children: item.tarifa
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                children: [
                                                                                                    item.visita == "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                                                            children: [
                                                                                                                " ",
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_19__.AiOutlineClose, {
                                                                                                                    className: "color-danger"
                                                                                                                })
                                                                                                            ]
                                                                                                        })
                                                                                                    }),
                                                                                                    item.visita != "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                        children: [
                                                                                                            item.visita,
                                                                                                            " bs"
                                                                                                        ]
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                children: [
                                                                                                    item.salida == "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                                                            children: [
                                                                                                                " ",
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_19__.AiOutlineClose, {
                                                                                                                    className: "color-danger"
                                                                                                                })
                                                                                                            ]
                                                                                                        })
                                                                                                    }),
                                                                                                    item.salida != "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                        children: [
                                                                                                            item.salida,
                                                                                                            " bs"
                                                                                                        ]
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                }, item.cod))
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_galeria___WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        show: showBidModal,
                        handleModal: handleBidModal,
                        data: archivoSelect
                    })
                ]
            });
        }
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("product-details-area", space === 1 && "rn-section-gapTop", className),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row g-5"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        children: " Querido usuario, debe completar datos importante para activar su perfil, Por favor complete su Perfil, Sobre Mi, Datos te Contacto y Ciudad Laboral. "
                    })
                ]
            })
        });
    }
};
ProductDetailsArea.propTypes = {
    space: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        1,
        2
    ]),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    product: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired),
        likeCount: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().number),
        price: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
            amount: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().number.isRequired),
            currency: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string.isRequired)
        }).isRequired,
        owner: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({}),
        collection: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({}),
        bids: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({})),
        properties: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({})),
        tags: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({})),
        history: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({})),
        highest_bid: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({}),
        auction_date: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        images: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_11__/* .ImageType */ .__)
    })
};
ProductDetailsArea.defaultProps = {
    space: 1
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductDetailsArea);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1984:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_product_layout_01__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1510);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8663);





const ProductArea = ({ space , className , data  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("product-area", space === 1 && "rn-section-gapTop", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row mb--30 align-items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "title mb--0",
                            "data-sal-delay": "150",
                            "data-sal": "slide-up",
                            "data-sal-duration": "800",
                            children: data?.section_title.title
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row g-5",
                    children: data?.products?.map((prod)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            "data-sal": "slide-up",
                            "data-sal-delay": "150",
                            "data-sal-duration": "800",
                            className: "col-5 col-lg-4 col-md-6 col-sm-6 col-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_layout_01__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                title: prod.title,
                                slug: prod.slug,
                                latestBid: prod.latestBid,
                                price: prod.price,
                                likeCount: prod.likeCount,
                                auction_date: prod.auction_date,
                                image: prod.images?.[0],
                                authors: prod.authors,
                                bitCount: prod.bitCount
                            })
                        }, prod.id))
                })
            ]
        })
    });
ProductArea.propTypes = {
    space: prop_types__WEBPACK_IMPORTED_MODULE_1___default().oneOf([
        1,
        2
    ]),
    className: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
    data: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        section_title: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
            title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
        }),
        products: prop_types__WEBPACK_IMPORTED_MODULE_1___default().arrayOf(_utils_types__WEBPACK_IMPORTED_MODULE_4__/* .ProductType */ .kv)
    })
};
ProductArea.defaultProps = {
    space: 1
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ProductArea)));


/***/ }),

/***/ 8543:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_seo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3191);
/* harmony import */ var _layout_wrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3019);
/* harmony import */ var _layout_header_header_01__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3555);
/* harmony import */ var _layout_footer_footer_01__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5728);
/* harmony import */ var _components_breadcrumb__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3578);
/* harmony import */ var _containers_product_details__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3002);
/* harmony import */ var _containers_product_layout_03__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1984);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8115);
/* harmony import */ var _utils_methods__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_utils_methods__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _data_products_json__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2537);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_header_header_01__WEBPACK_IMPORTED_MODULE_4__, _containers_product_details__WEBPACK_IMPORTED_MODULE_7__]);
([_layout_header_header_01__WEBPACK_IMPORTED_MODULE_4__, _containers_product_details__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










// demo data

const ProductDetails = ({ anuncio , recentViewProducts , relatedProducts , nombre  })=>{
    console.log(anuncio);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layout_wrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                pageTitle: nombre
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_header_header_01__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                id: "main-content",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_breadcrumb__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        pageTitle: nombre,
                        currentPage: nombre
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_containers_product_details__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        product: anuncio.anuncio[0],
                        servicios: anuncio.servicios,
                        tarifas: anuncio.tarifas
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_footer_footer_01__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    });
};
const getServerSideProps = async (context)=>{
    var requestOptionsPerfil = {
        method: "POST",
        body: JSON.stringify({
            usuario: context.query.slug
        })
    };
    const data = await fetch("https://bo.ubunnies.com/backendUbunnie/index.php/" + "perfil/getAnuncioByUsuario", requestOptionsPerfil);
    const result = await data.json();
    return {
        props: {
            anuncio: result,
            nombre: context.query.slug,
            className: "template-color-1"
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8103:
/***/ ((module) => {

module.exports = require("clsx");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8582:
/***/ ((module) => {

module.exports = require("react-bootstrap/Dropdown");

/***/ }),

/***/ 9306:
/***/ ((module) => {

module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 2540:
/***/ ((module) => {

module.exports = require("react-bootstrap/Nav");

/***/ }),

/***/ 6348:
/***/ ((module) => {

module.exports = require("react-bootstrap/TabContainer");

/***/ }),

/***/ 1130:
/***/ ((module) => {

module.exports = require("react-bootstrap/TabContent");

/***/ }),

/***/ 9722:
/***/ ((module) => {

module.exports = require("react-bootstrap/TabPane");

/***/ }),

/***/ 4449:
/***/ ((module) => {

module.exports = require("react-countdown");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 8519:
/***/ ((module) => {

module.exports = require("web3");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 7425:
/***/ ((module) => {

module.exports = import("react-icons/ai");;

/***/ }),

/***/ 6607:
/***/ ((module) => {

module.exports = import("react-icons/ci");;

/***/ }),

/***/ 1301:
/***/ ((module) => {

module.exports = import("react-icons/fa");;

/***/ }),

/***/ 7333:
/***/ ((module) => {

module.exports = import("react-icons/fa6");;

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("react-icons/io5");;

/***/ }),

/***/ 6905:
/***/ ((module) => {

module.exports = import("react-icons/md");;

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ }),

/***/ 2537:
/***/ ((module) => {

module.exports = [];

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,676,3061,5152,5973,6219,3578,1510,8353,3823], () => (__webpack_exec__(8543)));
module.exports = __webpack_exports__;

})();